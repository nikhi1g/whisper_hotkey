# Validation Report

**Packet date:** 2026-08-08  
**Scope:** Phase 1 only

## Completed checks

- Packet structure and local Markdown links: passed.
- Machine-readable source manifest: **57 source records**, passed.
- `luna_worker` orchestration tasks: **15 worker packets** present.
- JSON syntax: passed.
- JSON Schema Draft 2020-12 syntax: passed for all three schemas.
- Recognition, repair, and benchmark example documents: passed schema validation.
- Deterministic WER/CER, lexical-invariance, and paired-bootstrap tests: passed.
- Python syntax compilation: passed.
- Source IDs are unique, and every source has a caveat and HTTPS URL.
- Packet contains **89 files**; **88 non-manifest files** are covered by `MANIFEST.sha256`.

The detailed command output is in `VALIDATION_TRANSCRIPT.txt`.

## Audit boundary

The current repository was inspected through GitHub and raw source endpoints on **2026-08-08**. The latest public release visible was `v3.6.2` at commit `317fced`; current `main` is ahead. The build environment used to create this packet cannot compile the macOS application or run Apple Silicon inference, so this packet does not claim a local Xcode/Swift build, Core ML benchmark, Metal benchmark, or integrated application test. Worker packets W00 and W12 explicitly require the orchestrating agent to reproduce those measurements on the target Mac before implementation claims are accepted.

## Accuracy boundary

No included result demonstrates universal WER at or below 1%. The packet defines `WER <= 1%` as a promotion target on a frozen, scoped, clean-and-recoverable application corpus with a documented normalizer. It supplies the architecture, source traceability, confidence metrics, selective-repair metrics, safety constraints, and release gates needed to evaluate the target honestly.
