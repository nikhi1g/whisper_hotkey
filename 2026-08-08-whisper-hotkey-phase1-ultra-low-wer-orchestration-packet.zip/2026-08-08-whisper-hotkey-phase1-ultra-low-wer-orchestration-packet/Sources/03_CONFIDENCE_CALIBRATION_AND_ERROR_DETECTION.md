# Confidence Calibration And Error Detection

The entries below are decision aids, not a license to copy claims without reproduction.

## Confidence Estimation and Calibration

### Fast Entropy-Based Methods of Word-Level Confidence Estimation for End-To-End ASR

- **ID:** `entropy-confidence`
- **Type/status:** `paper` / `adopt-baseline`
- **URL:** https://arxiv.org/abs/2212.08703
- **Use for this project:** Low-cost word confidence for CTC and RNN-T; better error separation than max-probability baselines.
- **Caveat:** Must be calibrated on the app distribution; raw entropy is not a universal probability of correctness.

### BLSTM-Based Confidence Estimation for End-to-End Speech Recognition

- **ID:** `blstm-confidence`
- **Type/status:** `paper` / `reference`
- **URL:** https://arxiv.org/abs/2312.14609
- **Use for this project:** Sequence confidence modeling under highly imbalanced correct/error labels.
- **Caveat:** Trainable estimator adds model lifecycle complexity; start with calibrated non-trainable evidence.

### Identifying and Calibrating Overconfidence in Noisy Speech Recognition

- **ID:** `noise-calibration`
- **Type/status:** `paper` / `adopt-evaluation`
- **URL:** https://arxiv.org/abs/2509.07195
- **Use for this project:** Demonstrates high-confidence wrong tokens under noise and selective post-hoc calibration.
- **Caveat:** Reported numbers are on a specific noise benchmark; reproduce on application mixtures.

### Leveraging Beam Search Information for Confidence Estimation in E2E ASR

- **ID:** `srcem`
- **Type/status:** `paper` / `forward-looking-experiment`
- **URL:** https://arxiv.org/abs/2607.29299
- **Use for this project:** Architecture-independent token/word confidence from beam score and rank features; current 2026 calibration reference.
- **Caveat:** Very recent preprint. Reproduce before depending on it; use as a feature recipe, not unquestioned truth.

