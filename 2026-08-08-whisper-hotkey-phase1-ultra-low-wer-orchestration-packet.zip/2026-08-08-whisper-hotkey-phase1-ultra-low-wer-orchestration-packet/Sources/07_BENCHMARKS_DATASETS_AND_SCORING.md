# Benchmarks Datasets And Scoring

The entries below are decision aids, not a license to copy claims without reproduction.

## Benchmarks, Datasets and Scoring

### LibriSpeech ASR corpus

- **ID:** `librispeech`
- **Type/status:** `dataset` / `required-public`
- **URL:** https://www.openslr.org/12
- **Use for this project:** Clean/read-speech comparability and regression tracking.
- **Caveat:** Read speech is not representative of spontaneous hotkey dictation.

### Earnings-22

- **ID:** `earnings22`
- **Type/status:** `dataset` / `required-public`
- **URL:** https://github.com/revdotcom/speech-datasets/tree/main/earnings22
- **Use for this project:** Long-form, numbers, entities and business-domain speech.
- **Caveat:** Respect dataset terms and use its prescribed normalization.

### Contextual Earnings-22

- **ID:** `contextual-earnings22`
- **Type/status:** `paper_dataset` / `recommended`
- **URL:** https://arxiv.org/abs/2604.07354
- **Use for this project:** Contextual entity and terminology evaluation beyond aggregate WER.
- **Caveat:** New benchmark; confirm artifact availability and license before CI use.

### TED-LIUM Release 3

- **ID:** `tedlium3`
- **Type/status:** `dataset` / `required-public`
- **URL:** https://www.openslr.org/51
- **Use for this project:** Prepared speech with natural prosody and varied speakers.
- **Caveat:** Not equivalent to close-mic dictation.

### GigaSpeech

- **ID:** `gigaspeech`
- **Type/status:** `dataset` / `recommended`
- **URL:** https://github.com/SpeechColab/GigaSpeech
- **Use for this project:** Large, diverse English ASR evaluation/training reference.
- **Caveat:** Use only permitted evaluation splits; full corpus is large.

### AMI Meeting Corpus

- **ID:** `ami`
- **Type/status:** `dataset` / `recommended`
- **URL:** https://groups.inf.ed.ac.uk/ami/corpus/
- **Use for this project:** Conversational speech, overlap and room acoustics.
- **Caveat:** Phase 1 does not perform target-speaker personalization; report overlap separately.

### MUSAN

- **ID:** `musan`
- **Type/status:** `dataset` / `required-noise`
- **URL:** https://www.openslr.org/17
- **Use for this project:** Music, speech and noise mixtures for controlled SNR evaluation.
- **Caveat:** Synthetic mixtures do not replace real device/environment recordings.

### NIST SCTK / sclite

- **ID:** `sclite`
- **Type/status:** `tool` / `required-reference`
- **URL:** https://github.com/usnistgov/SCTK
- **Use for this project:** Canonical ASR scoring and alignment reference.
- **Caveat:** Document normalization so app metrics and public leaderboard metrics are not conflated.

