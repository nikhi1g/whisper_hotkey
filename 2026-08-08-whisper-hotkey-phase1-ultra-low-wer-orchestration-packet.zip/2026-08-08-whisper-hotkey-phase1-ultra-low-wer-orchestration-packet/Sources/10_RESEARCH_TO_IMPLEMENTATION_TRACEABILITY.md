# Research-to-Implementation Traceability

This file prevents papers from becoming decorative citations. Every research claim must map to a bounded experiment or implementation task.

| Source ID | Design conclusion | Worker(s) | Required verification |
|---|---|---|---|
| `repo-whisper-recognition`, `repo-parakeet-runtime` | Replace `String`-only boundaries with a provider-neutral rich result | W01, W02, W03 | Protocol fixtures, migration tests, unchanged baseline text |
| `repo-helper` | Preserve existing Whisper evidence, add per-token/word timing, and stop treating aggregate thresholds as calibrated confidence | W02, W05 | Evidence fixtures, ECE/AUPRC, adaptive fallback ablation |
| `fluidaudio-release-0155` | Preserve FluidAudio word timestamps and seam/chunk metadata available in the pinned release | W03 | Compile-time API audit and variant fixtures |
| `entropy-confidence` | Entropy is a low-cost RNNT/CTC confidence feature | W03, W05 | Error-detection AUPRC versus max posterior |
| `noise-calibration` | Confidence can be dangerously overconfident under noise | W05, W12 | SNR-stratified ECE/MCE/NCE and high-confidence error rate |
| `srcem` | Beam score/rank features may improve architecture-independent calibration | W02, W05 | Reproduction behind an experiment flag; compare with simpler calibration |
| `acoustic-confidence-correction` | Corrections should use original acoustic evidence plus localized confidence, not text alone | W07, W08 | Selective-span oracle, repair precision and false-rewrite metrics |
| `rover` | Align recognizer outputs before voting/fusion | W08 | Timestamp-aware DP tests and disagreement fixtures |
| `mbr-asr-2025`, `ambr` | Bounded MBR/medoid selection may outperform top-score/beam choice | W06, W08 | Candidate-count/latency ablation and paired WER |
| `semantic-segmentation` | Sentence completeness is a better endpoint signal than pause duration alone | W09, W10 | Thinking-pause, fragments and endpoint-latency suite |
| `simul-whisper` | Streaming needs explicit truncated-word and revisable-tail handling | W02, W10 | Chunk-edge word tests and stable-prefix metrics |
| `whisperx-paper` | VAD cut/merge and alignment improve long-form timing and segmentation | W07, W10 | Timing error and seam-drop/repetition tests |
| `punctuation-lookahead` | Punctuation should be label-only with bounded future context | W09 | Lexical invariance = 100%, punctuation/boundary F1 |
| `whisper-turbo-card` | Full large-v3 is a rational stronger same-family verifier because Turbo is decoder-pruned | W06 | Selective-span accuracy, latency and correlated-error analysis |
| `parakeet-hybrid-11b-card`, `parakeetcpp` | A 1.1B Parakeet is a larger Apple-local verifier candidate | W06, W13 | Exact model/runtime hashes, Metal latency/RSS and repair precision |
| `qwen3-asr-repo`, `mlx-audio` | Qwen3-ASR is a forward-looking alternate verifier, not a default dependency | W06 | Local Apple feasibility, license, memory, accuracy and distribution audit |
| `librispeech`, `earnings22`, `musan`, `ami` | A single read-speech smoke set cannot justify the product claim | W12 | Frozen multi-domain benchmark and separately reported subsets |

## Rule

A source can support a hypothesis. Only a reproducible local experiment can support integration or a product accuracy claim.
