# Forward-Citation and Freshness Map

**Cutoff checked:** 2026-08-08

The orchestrator must not select a technique solely because it is newer. New work is promoted only after local reproduction, paired benchmarking and safety checks. This map shows which newer sources extend older foundations.

| Foundation | Newer development | What changed | Packet decision |
|---|---|---|---|
| Whisper (2022) | Turbo model card (2024) | Decoder reduced from 32 layers to 4 for speed with some quality loss | Keep Turbo as a fast primary; benchmark full large-v3 as a verifier |
| Whisper buffered decoding | WhisperX (2023), Simul-Whisper (2024), Whisper-CD (2026) | VAD/forced alignment, truncation detection, and contrastive anti-hallucination decoding | Adopt VAD/overlap/stable-tail principles now; gate contrastive decoding as experimental |
| Max-token confidence | Entropy confidence (2022), noisy calibration (2025), SR-CEM (2026) | Better word error separation, explicit calibration under noise, architecture-independent beam features | Implement calibrated feature fusion; evaluate SR-CEM after rich N-best evidence exists |
| Whole-utterance retry | Acoustic + confidence correction (2024) | Localizes errors using confidence plus original acoustic evidence | Selectively re-decode bounded uncertain spans instead of repeating everything |
| ROVER voting (1997) | MBR ASR evaluation (2025), faster medoid/MBR work | Candidate selection based on expected utility rather than only top model score | Use confidence-weighted alignment and bounded MBR/medoid experiments |
| Pause-only endpointing | Semantic segmentation (2023), bounded lookahead punctuation (2026) | Semantic completeness and word-preserving punctuation improve boundaries | Separate acoustic pause evidence from final sentence-boundary decisions |
| Parakeet NeMo checkpoints | FluidAudio 0.15.5, parakeet.cpp 2026 | Native Apple/ggml inference, word timestamps, streaming and larger model coverage | Preserve FluidAudio primary path; benchmark parakeet.cpp 1.1B as verifier, not automatic replacement |

## Freshness procedure for the implementing agent

1. Record the repository commit SHA and all dependency/model hashes before coding.
2. Re-open every source with status `adopt-current`, `benchmark-verifier`, or `forward-looking-experiment`.
3. Search for releases, corrections, withdrawals and successor papers newer than this packet.
4. Prefer a newer source only when it improves the relevant metric under comparable conditions.
5. Store reproduction commands and raw output. Never cite a secondary leaderboard when the primary model card or paper is available.
