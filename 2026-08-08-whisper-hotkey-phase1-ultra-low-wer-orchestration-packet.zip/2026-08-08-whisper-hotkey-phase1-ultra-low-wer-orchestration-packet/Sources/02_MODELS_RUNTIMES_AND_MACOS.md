# Models Runtimes And Macos

The entries below are decision aids, not a license to copy claims without reproduction.

## macOS and Apple Silicon Runtimes

### FluidAudio v0.15.5 release

- **ID:** `fluidaudio-release-0155`
- **Type/status:** `release` / `adopt-current`
- **URL:** https://github.com/FluidInference/FluidAudio/releases/tag/0.15.5
- **Use for this project:** Pinned dependency capabilities: unified Parakeet ASR, native Swift mel, word timestamps, seam repair, vocabulary controls.
- **Caveat:** Inspect exact public result/evidence APIs in the resolved 0.15.5 checkout; release notes do not guarantee every score needed for calibration.

### FluidAudio

- **ID:** `fluidaudio-repo`
- **Type/status:** `repository` / `adopt-current`
- **URL:** https://github.com/FluidInference/FluidAudio
- **Use for this project:** Core ML and Apple Neural Engine ASR, VAD, diarization and speaker utilities.
- **Caveat:** Phase 1 must not add speaker personalization or corpus persistence.

### whisper.cpp

- **ID:** `whispercpp`
- **Type/status:** `repository` / `adopt-current`
- **URL:** https://github.com/ggml-org/whisper.cpp
- **Use for this project:** Apple Silicon Metal/Core ML/Accelerate runtime, token data, timestamps, beam search, VAD and low-allocation native integration.
- **Caveat:** Pin and benchmark a release; do not rely on mutable master behavior.

### whisper.cpp v1.9.1

- **ID:** `whispercpp-191`
- **Type/status:** `release` / `benchmark`
- **URL:** https://github.com/ggml-org/whisper.cpp/releases/tag/v1.9.1
- **Use for this project:** Current stable release candidate for a pinned helper/runtime upgrade.
- **Caveat:** A version bump is not automatically an accuracy improvement; run regression benchmarks.

### parakeet.cpp

- **ID:** `parakeetcpp`
- **Type/status:** `repository` / `benchmark`
- **URL:** https://github.com/mudler/parakeet.cpp
- **Use for this project:** Native C++/ggml Parakeet inference, Metal builds, 0.6B/1.1B models, word timestamps, streaming EOU and a C API.
- **Caveat:** Its WER 0 parity claim means parity with NeMo output, not zero transcription error. Benchmark model accuracy and Metal contention in this app.

### WhisperKit

- **ID:** `whisperkit`
- **Type/status:** `repository` / `reference`
- **URL:** https://github.com/argmaxinc/WhisperKit
- **Use for this project:** Native Swift/Core ML Whisper implementation, streaming policies, word timings, decoding options and Apple deployment patterns.
- **Caveat:** Using it as a second Whisper runtime may add substantial dependency and model complexity; evaluate rather than assume.

### whisper-timestamped

- **ID:** `whisper-timestamped`
- **Type/status:** `repository` / `reference`
- **URL:** https://github.com/linto-ai/whisper-timestamped
- **Use for this project:** Reference implementation for word timestamps, confidence extraction, VAD and Whisper fallback behavior.
- **Caveat:** Python reference, not a production Swift dependency.

### WhisperX

- **ID:** `whisperx-repo`
- **Type/status:** `repository` / `reference`
- **URL:** https://github.com/m-bain/whisperX
- **Use for this project:** VAD cut/merge, forced alignment, long-form word timings and batching patterns.
- **Caveat:** Its alignment models and Python stack are not direct macOS app dependencies.

### faster-whisper

- **ID:** `faster-whisper`
- **Type/status:** `repository` / `reference`
- **URL:** https://github.com/SYSTRAN/faster-whisper
- **Use for this project:** Production-oriented batching, VAD, word timestamps and decoding controls.
- **Caveat:** CTranslate2 is not the current native macOS path; use as an algorithm/API reference.

### parakeet-mlx

- **ID:** `parakeet-mlx`
- **Type/status:** `repository` / `benchmark`
- **URL:** https://github.com/senstella/parakeet-mlx
- **Use for this project:** Alternative Apple Silicon Parakeet runtime and 1.1B model experimentation.
- **Caveat:** Python/MLX integration may be unsuitable for shipping; use primarily to establish model-quality ceilings.

### mlx-audio

- **ID:** `mlx-audio`
- **Type/status:** `repository` / `experimental`
- **URL:** https://github.com/Blaizzy/mlx-audio
- **Use for this project:** Apple Silicon experiments with Parakeet, Qwen3-ASR, forced alignment and other speech models.
- **Caveat:** Broad project surface and model conversions require independent correctness and license review.

## Models and Model Cards

### Qwen3-ASR

- **ID:** `qwen3-asr-repo`
- **Type/status:** `repository` / `experimental-verifier`
- **URL:** https://github.com/QwenLM/Qwen3-ASR
- **Use for this project:** 1.7B high-accuracy ASR candidate, 0.6B forced aligner, streaming/offline reference APIs.
- **Caveat:** Official runtime is CUDA-oriented. Apple MLX ports are experimental and must beat full Whisper large-v3 or Parakeet 1.1B within memory and latency budgets.

### Whisper large-v3-turbo model card

- **ID:** `whisper-turbo-card`
- **Type/status:** `model_card` / `current-primary-option`
- **URL:** https://huggingface.co/openai/whisper-large-v3-turbo
- **Use for this project:** Turbo is pruned from large-v3 by reducing decoder layers from 32 to 4, gaining speed with minor quality loss.
- **Caveat:** This makes full large-v3 a plausible verifier, not proof that it will improve every uncertain span.

### Whisper large-v3 model card

- **ID:** `whisper-large-v3-card`
- **Type/status:** `model_card` / `benchmark-verifier`
- **URL:** https://huggingface.co/openai/whisper-large-v3
- **Use for this project:** Higher-capacity Whisper verifier candidate with compatible acoustics and prompt controls.
- **Caveat:** Shared model family errors may be correlated with Turbo; complementary Parakeet verification must also be tested.

### Parakeet Unified English 0.6B model card

- **ID:** `parakeet-unified-card`
- **Type/status:** `model_card` / `current-primary-option`
- **URL:** https://huggingface.co/nvidia/parakeet-unified-en-0.6b
- **Use for this project:** Offline/streaming unified FastConformer-RNNT, punctuation/capitalization, published aggregate WER table.
- **Caveat:** The published 5.91% average is dataset-dependent and cannot be converted into a universal product accuracy guarantee.

### Parakeet TDT 1.1B model card

- **ID:** `parakeet-tdt-11b-card`
- **Type/status:** `model_card` / `benchmark-verifier`
- **URL:** https://huggingface.co/nvidia/parakeet-tdt-1.1b
- **Use for this project:** Larger Parakeet verifier candidate.
- **Caveat:** Lowercase output and model size affect formatting and memory; use original audio plus independent punctuation layer.

### Parakeet TDT-CTC 1.1B model card

- **ID:** `parakeet-hybrid-11b-card`
- **Type/status:** `model_card` / `benchmark-verifier`
- **URL:** https://huggingface.co/nvidia/parakeet-tdt_ctc-1.1b
- **Use for this project:** 1.1B hybrid model with TDT and CTC heads, published corpus-specific WERs, punctuation/capitalization.
- **Caveat:** Published LibriSpeech test-clean WER near 1.82% still does not meet the desired app-level target alone.

### Qwen3-ASR 1.7B model card

- **ID:** `qwen3-asr-card`
- **Type/status:** `model_card` / `experimental-verifier`
- **URL:** https://huggingface.co/Qwen/Qwen3-ASR-1.7B
- **Use for this project:** Forward-looking high-capacity verifier candidate and complex acoustic robustness.
- **Caveat:** Do not introduce it unless an Apple-local implementation is stable, licensed, memory-bounded and measurably superior.

## Foundational ASR Research

### Robust Speech Recognition via Large-Scale Weak Supervision

- **ID:** `whisper-paper`
- **Type/status:** `paper` / `background`
- **URL:** https://arxiv.org/abs/2212.04356
- **Use for this project:** Whisper architecture, robustness and decoding background.
- **Caveat:** Original paper predates Turbo and current native runtimes.

### Fast Conformer with Linearly Scalable Attention for Efficient Speech Recognition

- **ID:** `fastconformer-paper`
- **Type/status:** `paper` / `background`
- **URL:** https://arxiv.org/abs/2305.05084
- **Use for this project:** Parakeet/FastConformer architecture and efficient long-form processing.
- **Caveat:** Architecture paper, not app-specific verifier evidence.

### Efficient Sequence Transduction by Jointly Predicting Tokens and Durations

- **ID:** `tdt-paper`
- **Type/status:** `paper` / `background`
- **URL:** https://arxiv.org/abs/2304.06795
- **Use for this project:** TDT decoder principles used by Parakeet models.
- **Caveat:** Does not define the required application confidence calibration.

