# Current Repository Sources

The entries below are decision aids, not a license to copy claims without reproduction.

## Current Repository Audit

### whisper_hotkey repository (main)

- **ID:** `repo-main`
- **Type/status:** `repository` / `required`
- **URL:** https://github.com/nikhi1g/whisper_hotkey
- **Use for this project:** Current product behavior, release surface, model and mode inventory.
- **Caveat:** Main is mutable. Re-audit before implementation and record the commit SHA locally.

### Package.swift

- **ID:** `repo-package`
- **Type/status:** `source` / `required`
- **URL:** https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Package.swift
- **Use for this project:** Swift 6, macOS 14, exact FluidAudio 0.15.5 dependency, target boundaries.
- **Caveat:** Raw main URL is mutable.

### WhisperRecognition.swift

- **ID:** `repo-whisper-recognition`
- **Type/status:** `source` / `required`
- **URL:** https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Sources/WhisperHotkeyASR/WhisperRecognition.swift
- **Use for this project:** Confirms current String-only recognition API, helper protocol, command fallback, audio deletion ownership.
- **Caveat:** Line numbers can drift; search by symbol names.

### ParakeetRuntime.swift

- **ID:** `repo-parakeet-runtime`
- **Type/status:** `source` / `required`
- **URL:** https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Sources/WhisperHotkeyASR/ParakeetRuntime.swift
- **Use for this project:** Confirms FluidAudio result is collapsed to text.
- **Caveat:** Re-check FluidAudio API at the pinned version.

### WhisperModelHelper/main.cpp

- **ID:** `repo-helper`
- **Type/status:** `source` / `required`
- **URL:** https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Sources/WhisperModelHelper/main.cpp
- **Use for this project:** Existing aggregate uncertainty and adaptive whole-utterance beam fallback; timestamps currently disabled.
- **Caveat:** Aggregate scores are not calibrated per-word confidence.

### BackgroundPredecode.swift

- **ID:** `repo-background-predecode`
- **Type/status:** `source` / `required`
- **URL:** https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Sources/WhisperHotkeyCore/BackgroundPredecode.swift
- **Use for this project:** Confirms decode-while-speaking stores independent strings and joins them.
- **Caveat:** Must be replaced with stable word/timing state, not merely patched with more string concatenation.

### Current architecture documentation

- **ID:** `repo-architecture`
- **Type/status:** `documentation` / `required`
- **URL:** https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/docs/ARCHITECTURE.md
- **Use for this project:** Current serialization, cancellation, privacy and insertion invariants.
- **Caveat:** Preserve single ordered delivery even when adding internal concurrency.

### Current model documentation

- **ID:** `repo-models`
- **Type/status:** `documentation` / `required`
- **URL:** https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/docs/MODELS.md
- **Use for this project:** Current engine profiles and benchmark claims.
- **Caveat:** The existing 100-utterance benchmark is a smoke test, not evidence for a universal sub-1% WER claim.

### SUBAGENTS.md

- **ID:** `repo-subagents`
- **Type/status:** `documentation` / `required`
- **URL:** https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/SUBAGENTS.md
- **Use for this project:** Repository-native worktree and sub-agent integration discipline.
- **Caveat:** The orchestrator must assign exact non-overlapping owned paths.


### whisper_hotkey 3.6.2 release

- **ID:** `repo-release-362`
- **Type/status:** `release` / `required-release-baseline`
- **URL:** https://github.com/nikhi1g/whisper_hotkey/releases/tag/v3.6.2
- **Use for this project:** Latest public release visible on 2026-08-08; tag `v3.6.2` at commit `317fced`. Establishes the user-facing release baseline.
- **Caveat:** Current `main` is ahead of the release. Benchmark and audit the exact branch/tag being changed; do not mix release claims with main-source behavior.
