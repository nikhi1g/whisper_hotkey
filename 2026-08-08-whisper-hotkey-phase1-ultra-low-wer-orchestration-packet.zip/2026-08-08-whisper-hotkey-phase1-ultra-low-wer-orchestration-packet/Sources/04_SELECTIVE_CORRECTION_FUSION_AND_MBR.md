# Selective Correction Fusion And Mbr

The entries below are decision aids, not a license to copy claims without reproduction.

## Selective Error Detection and Repair

### Error Correction by Paying Attention to Both Acoustic and Confidence References for Automatic Speech Recognition

- **ID:** `acoustic-confidence-correction`
- **Type/status:** `paper` / `design-reference`
- **URL:** https://arxiv.org/abs/2407.12817
- **Use for this project:** Combines aligned N-best hypotheses, acoustic features and confidence to localize and repair errors.
- **Caveat:** Research model is not a drop-in local Mac component; extract the architectural principle.

## Candidate Fusion and Decision Theory

### Recognizer Output Voting Error Reduction (ROVER)

- **ID:** `rover`
- **Type/status:** `paper` / `adopt-principle`
- **URL:** https://www.nist.gov/publications/post-processing-system-yield-reduced-word-error-rates-recognizer-output-voting-error
- **Use for this project:** Dynamic-programming alignment and voting across recognizer outputs.
- **Caveat:** Plain majority vote is insufficient; weight by calibrated confidence and protect high-confidence anchors.

### Re-evaluating Minimum Bayes Risk Decoding for Automatic Speech Recognition

- **ID:** `mbr-asr-2025`
- **Type/status:** `paper` / `benchmark`
- **URL:** https://arxiv.org/abs/2510.19471
- **Use for this project:** Evidence that sample-based MBR can outperform beam search in Whisper ASR settings.
- **Caveat:** Candidate generation and utility choice dominate results and cost; use only on bounded uncertain spans.

### Hyperparameter-Free Approach for Faster Minimum Bayes Risk Decoding

- **ID:** `ambr`
- **Type/status:** `paper` / `reference`
- **URL:** https://arxiv.org/abs/2401.02749
- **Use for this project:** Medoid framing and reduced-compute approximate MBR.
- **Caveat:** Evaluated primarily on text generation tasks; apply cautiously to small ASR candidate sets.

### mbrs: A Library for Minimum Bayes Risk Decoding

- **ID:** `mbrs-library`
- **Type/status:** `paper` / `reference`
- **URL:** https://arxiv.org/abs/2408.04167
- **Use for this project:** Transparent, reproducible MBR implementation patterns and compute accounting.
- **Caveat:** Python library is an offline experiment reference, not a shipping dependency.

## Advanced Decoding

### Whisper-CD: Accurate Long-Form Speech Recognition using Multi-Negative Contrastive Decoding

- **ID:** `whisper-cd`
- **Type/status:** `paper` / `experimental`
- **URL:** https://arxiv.org/abs/2603.06193
- **Use for this project:** Training-free contrastive decoding to reduce Whisper hallucination, repetition and omission on long-form audio.
- **Caveat:** Very recent and more invasive than selective repair. Keep behind an experiment flag until reproduced locally.

