# Production Implementation References

The entries below are decision aids, not a license to copy claims without reproduction.

## Production/Open-Source App References

### OpenWhispr

- **ID:** `openwhispr`
- **Type/status:** `repository` / `reference`
- **URL:** https://github.com/OpenWhispr/openwhispr
- **Use for this project:** Cross-platform local Parakeet/Whisper hotkey product patterns and packaging.
- **Caveat:** Do not infer undocumented proprietary-quality techniques from marketing claims.

### Pindrop

- **ID:** `pindrop`
- **Type/status:** `repository` / `reference`
- **URL:** https://github.com/watzon/pindrop
- **Use for this project:** Native macOS menu-bar dictation, multiple local engines and streaming UX patterns.
- **Caveat:** Review licenses before copying code; architecture may differ from this app.

### TypeWhisper

- **ID:** `typewhisper`
- **Type/status:** `repository_org` / `reference`
- **URL:** https://github.com/TypeWhisper
- **Use for this project:** Multi-engine on-device dictation and per-app profile patterns.
- **Caveat:** Use only publicly verifiable implementation details.

### OpenSuperWhisper

- **ID:** `opensuperwhisper`
- **Type/status:** `repository` / `reference`
- **URL:** https://github.com/Starmel/OpenSuperWhisper
- **Use for this project:** macOS hotkeys, Whisper/Parakeet engine selection and recording UX.
- **Caveat:** Reference product mechanics, not accuracy claims.

