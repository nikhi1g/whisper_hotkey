# Source Index

**Checked:** 2026-08-08

This index is intentionally primary-source-heavy. Every source has a stated use and caveat. A model card or repository claim is not treated as independent proof of product accuracy.

## Decision hierarchy

1. Current repository source establishes what exists.
2. Official model cards/releases establish supported model/runtime capabilities.
3. Papers establish techniques to reproduce and benchmark.
4. Public apps are implementation references only, never evidence that a specific accuracy target is achieved.

## Sources

### Current Repository Audit

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `repo-main` | [whisper_hotkey repository (main)](https://github.com/nikhi1g/whisper_hotkey) | `required` | Current product behavior, release surface, model and mode inventory. | Main is mutable. Re-audit before implementation and record the commit SHA locally. |
| `repo-release-362` | [whisper_hotkey 3.6.2 release](https://github.com/nikhi1g/whisper_hotkey/releases/tag/v3.6.2) | `required-release-baseline` | Latest public release visible on 2026-08-08; tag v3.6.2 at commit 317fced. | Current main is ahead; keep release and main evidence separate. |
| `repo-package` | [Package.swift](https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Package.swift) | `required` | Swift 6, macOS 14, exact FluidAudio 0.15.5 dependency, target boundaries. | Raw main URL is mutable. |
| `repo-whisper-recognition` | [WhisperRecognition.swift](https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Sources/WhisperHotkeyASR/WhisperRecognition.swift) | `required` | Confirms current String-only recognition API, helper protocol, command fallback, audio deletion ownership. | Line numbers can drift; search by symbol names. |
| `repo-parakeet-runtime` | [ParakeetRuntime.swift](https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Sources/WhisperHotkeyASR/ParakeetRuntime.swift) | `required` | Confirms FluidAudio result is collapsed to text. | Re-check FluidAudio API at the pinned version. |
| `repo-helper` | [WhisperModelHelper/main.cpp](https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Sources/WhisperModelHelper/main.cpp) | `required` | Existing aggregate uncertainty and adaptive whole-utterance beam fallback; timestamps currently disabled. | Aggregate scores are not calibrated per-word confidence. |
| `repo-background-predecode` | [BackgroundPredecode.swift](https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/Sources/WhisperHotkeyCore/BackgroundPredecode.swift) | `required` | Confirms decode-while-speaking stores independent strings and joins them. | Must be replaced with stable word/timing state, not merely patched with more string concatenation. |
| `repo-architecture` | [Current architecture documentation](https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/docs/ARCHITECTURE.md) | `required` | Current serialization, cancellation, privacy and insertion invariants. | Preserve single ordered delivery even when adding internal concurrency. |
| `repo-models` | [Current model documentation](https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/docs/MODELS.md) | `required` | Current engine profiles and benchmark claims. | The existing 100-utterance benchmark is a smoke test, not evidence for a universal sub-1% WER claim. |
| `repo-subagents` | [SUBAGENTS.md](https://raw.githubusercontent.com/nikhi1g/whisper_hotkey/main/SUBAGENTS.md) | `required` | Repository-native worktree and sub-agent integration discipline. | The orchestrator must assign exact non-overlapping owned paths. |

### macOS and Apple Silicon Runtimes

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `fluidaudio-release-0155` | [FluidAudio v0.15.5 release](https://github.com/FluidInference/FluidAudio/releases/tag/0.15.5) | `adopt-current` | Pinned dependency capabilities: unified Parakeet ASR, native Swift mel, word timestamps, seam repair, vocabulary controls. | Inspect exact public result/evidence APIs in the resolved 0.15.5 checkout; release notes do not guarantee every score needed for calibration. |
| `fluidaudio-repo` | [FluidAudio](https://github.com/FluidInference/FluidAudio) | `adopt-current` | Core ML and Apple Neural Engine ASR, VAD, diarization and speaker utilities. | Phase 1 must not add speaker personalization or corpus persistence. |
| `whispercpp` | [whisper.cpp](https://github.com/ggml-org/whisper.cpp) | `adopt-current` | Apple Silicon Metal/Core ML/Accelerate runtime, token data, timestamps, beam search, VAD and low-allocation native integration. | Pin and benchmark a release; do not rely on mutable master behavior. |
| `whispercpp-191` | [whisper.cpp v1.9.1](https://github.com/ggml-org/whisper.cpp/releases/tag/v1.9.1) | `benchmark` | Current stable release candidate for a pinned helper/runtime upgrade. | A version bump is not automatically an accuracy improvement; run regression benchmarks. |
| `parakeetcpp` | [parakeet.cpp](https://github.com/mudler/parakeet.cpp) | `benchmark` | Native C++/ggml Parakeet inference, Metal builds, 0.6B/1.1B models, word timestamps, streaming EOU and a C API. | Its WER 0 parity claim means parity with NeMo output, not zero transcription error. Benchmark model accuracy and Metal contention in this app. |
| `whisperkit` | [WhisperKit](https://github.com/argmaxinc/WhisperKit) | `reference` | Native Swift/Core ML Whisper implementation, streaming policies, word timings, decoding options and Apple deployment patterns. | Using it as a second Whisper runtime may add substantial dependency and model complexity; evaluate rather than assume. |
| `whisper-timestamped` | [whisper-timestamped](https://github.com/linto-ai/whisper-timestamped) | `reference` | Reference implementation for word timestamps, confidence extraction, VAD and Whisper fallback behavior. | Python reference, not a production Swift dependency. |
| `whisperx-repo` | [WhisperX](https://github.com/m-bain/whisperX) | `reference` | VAD cut/merge, forced alignment, long-form word timings and batching patterns. | Its alignment models and Python stack are not direct macOS app dependencies. |
| `faster-whisper` | [faster-whisper](https://github.com/SYSTRAN/faster-whisper) | `reference` | Production-oriented batching, VAD, word timestamps and decoding controls. | CTranslate2 is not the current native macOS path; use as an algorithm/API reference. |
| `parakeet-mlx` | [parakeet-mlx](https://github.com/senstella/parakeet-mlx) | `benchmark` | Alternative Apple Silicon Parakeet runtime and 1.1B model experimentation. | Python/MLX integration may be unsuitable for shipping; use primarily to establish model-quality ceilings. |
| `mlx-audio` | [mlx-audio](https://github.com/Blaizzy/mlx-audio) | `experimental` | Apple Silicon experiments with Parakeet, Qwen3-ASR, forced alignment and other speech models. | Broad project surface and model conversions require independent correctness and license review. |

### Models and Model Cards

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `qwen3-asr-repo` | [Qwen3-ASR](https://github.com/QwenLM/Qwen3-ASR) | `experimental-verifier` | 1.7B high-accuracy ASR candidate, 0.6B forced aligner, streaming/offline reference APIs. | Official runtime is CUDA-oriented. Apple MLX ports are experimental and must beat full Whisper large-v3 or Parakeet 1.1B within memory and latency budgets. |
| `whisper-turbo-card` | [Whisper large-v3-turbo model card](https://huggingface.co/openai/whisper-large-v3-turbo) | `current-primary-option` | Turbo is pruned from large-v3 by reducing decoder layers from 32 to 4, gaining speed with minor quality loss. | This makes full large-v3 a plausible verifier, not proof that it will improve every uncertain span. |
| `whisper-large-v3-card` | [Whisper large-v3 model card](https://huggingface.co/openai/whisper-large-v3) | `benchmark-verifier` | Higher-capacity Whisper verifier candidate with compatible acoustics and prompt controls. | Shared model family errors may be correlated with Turbo; complementary Parakeet verification must also be tested. |
| `parakeet-unified-card` | [Parakeet Unified English 0.6B model card](https://huggingface.co/nvidia/parakeet-unified-en-0.6b) | `current-primary-option` | Offline/streaming unified FastConformer-RNNT, punctuation/capitalization, published aggregate WER table. | The published 5.91% average is dataset-dependent and cannot be converted into a universal product accuracy guarantee. |
| `parakeet-tdt-11b-card` | [Parakeet TDT 1.1B model card](https://huggingface.co/nvidia/parakeet-tdt-1.1b) | `benchmark-verifier` | Larger Parakeet verifier candidate. | Lowercase output and model size affect formatting and memory; use original audio plus independent punctuation layer. |
| `parakeet-hybrid-11b-card` | [Parakeet TDT-CTC 1.1B model card](https://huggingface.co/nvidia/parakeet-tdt_ctc-1.1b) | `benchmark-verifier` | 1.1B hybrid model with TDT and CTC heads, published corpus-specific WERs, punctuation/capitalization. | Published LibriSpeech test-clean WER near 1.82% still does not meet the desired app-level target alone. |
| `qwen3-asr-card` | [Qwen3-ASR 1.7B model card](https://huggingface.co/Qwen/Qwen3-ASR-1.7B) | `experimental-verifier` | Forward-looking high-capacity verifier candidate and complex acoustic robustness. | Do not introduce it unless an Apple-local implementation is stable, licensed, memory-bounded and measurably superior. |

### Foundational ASR Research

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `whisper-paper` | [Robust Speech Recognition via Large-Scale Weak Supervision](https://arxiv.org/abs/2212.04356) | `background` | Whisper architecture, robustness and decoding background. | Original paper predates Turbo and current native runtimes. |
| `fastconformer-paper` | [Fast Conformer with Linearly Scalable Attention for Efficient Speech Recognition](https://arxiv.org/abs/2305.05084) | `background` | Parakeet/FastConformer architecture and efficient long-form processing. | Architecture paper, not app-specific verifier evidence. |
| `tdt-paper` | [Efficient Sequence Transduction by Jointly Predicting Tokens and Durations](https://arxiv.org/abs/2304.06795) | `background` | TDT decoder principles used by Parakeet models. | Does not define the required application confidence calibration. |

### Confidence Estimation and Calibration

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `entropy-confidence` | [Fast Entropy-Based Methods of Word-Level Confidence Estimation for End-To-End ASR](https://arxiv.org/abs/2212.08703) | `adopt-baseline` | Low-cost word confidence for CTC and RNN-T; better error separation than max-probability baselines. | Must be calibrated on the app distribution; raw entropy is not a universal probability of correctness. |
| `blstm-confidence` | [BLSTM-Based Confidence Estimation for End-to-End Speech Recognition](https://arxiv.org/abs/2312.14609) | `reference` | Sequence confidence modeling under highly imbalanced correct/error labels. | Trainable estimator adds model lifecycle complexity; start with calibrated non-trainable evidence. |
| `noise-calibration` | [Identifying and Calibrating Overconfidence in Noisy Speech Recognition](https://arxiv.org/abs/2509.07195) | `adopt-evaluation` | Demonstrates high-confidence wrong tokens under noise and selective post-hoc calibration. | Reported numbers are on a specific noise benchmark; reproduce on application mixtures. |
| `srcem` | [Leveraging Beam Search Information for Confidence Estimation in E2E ASR](https://arxiv.org/abs/2607.29299) | `forward-looking-experiment` | Architecture-independent token/word confidence from beam score and rank features; current 2026 calibration reference. | Very recent preprint. Reproduce before depending on it; use as a feature recipe, not unquestioned truth. |

### Selective Error Detection and Repair

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `acoustic-confidence-correction` | [Error Correction by Paying Attention to Both Acoustic and Confidence References for Automatic Speech Recognition](https://arxiv.org/abs/2407.12817) | `design-reference` | Combines aligned N-best hypotheses, acoustic features and confidence to localize and repair errors. | Research model is not a drop-in local Mac component; extract the architectural principle. |

### Candidate Fusion and Decision Theory

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `rover` | [Recognizer Output Voting Error Reduction (ROVER)](https://www.nist.gov/publications/post-processing-system-yield-reduced-word-error-rates-recognizer-output-voting-error) | `adopt-principle` | Dynamic-programming alignment and voting across recognizer outputs. | Plain majority vote is insufficient; weight by calibrated confidence and protect high-confidence anchors. |
| `mbr-asr-2025` | [Re-evaluating Minimum Bayes Risk Decoding for Automatic Speech Recognition](https://arxiv.org/abs/2510.19471) | `benchmark` | Evidence that sample-based MBR can outperform beam search in Whisper ASR settings. | Candidate generation and utility choice dominate results and cost; use only on bounded uncertain spans. |
| `ambr` | [Hyperparameter-Free Approach for Faster Minimum Bayes Risk Decoding](https://arxiv.org/abs/2401.02749) | `reference` | Medoid framing and reduced-compute approximate MBR. | Evaluated primarily on text generation tasks; apply cautiously to small ASR candidate sets. |
| `mbrs-library` | [mbrs: A Library for Minimum Bayes Risk Decoding](https://arxiv.org/abs/2408.04167) | `reference` | Transparent, reproducible MBR implementation patterns and compute accounting. | Python library is an offline experiment reference, not a shipping dependency. |

### Streaming and Semantic Segmentation

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `semantic-segmentation` | [Semantic Segmentation with Bidirectional Language Models Improves Long-form ASR](https://arxiv.org/abs/2305.18419) | `adopt-principle` | Sentence completeness can outperform pause-only segmentation while reducing WER and endpoint latency. | The app needs bounded local inference and deterministic commit rules, not unrestricted remote LM segmentation. |
| `simul-whisper` | [Simul-Whisper: Attention-Guided Streaming Whisper with Truncation Detection](https://arxiv.org/abs/2406.10052) | `design-reference` | Cross-attention-guided chunking and explicit truncated-word detection for streaming Whisper. | Implement concepts compatible with the current helper; do not import an incompatible runtime wholesale. |

### Timestamps and Alignment

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `whisperx-paper` | [WhisperX: Time-Accurate Speech Transcription of Long-Form Audio](https://arxiv.org/abs/2303.00747) | `design-reference` | VAD cut/merge, forced alignment and long-form word timing. | Forced alignment cannot fix lexical errors by itself and should not become the only source of confidence. |

### Advanced Decoding

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `whisper-cd` | [Whisper-CD: Accurate Long-Form Speech Recognition using Multi-Negative Contrastive Decoding](https://arxiv.org/abs/2603.06193) | `experimental` | Training-free contrastive decoding to reduce Whisper hallucination, repetition and omission on long-form audio. | Very recent and more invasive than selective repair. Keep behind an experiment flag until reproduced locally. |

### Punctuation and Sentence Boundaries

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `punctuation-lookahead` | [Efficient Punctuation Restoration via Weighted Lookahead Scoring Method for Streaming ASR Systems](https://arxiv.org/abs/2606.05179) | `adopt-principle` | Non-autoregressive, input-preserving punctuation decisions with bounded lookahead and calibrated thresholds. | A paper score does not establish English dictation quality; benchmark on pauses, fragments and technical prose. |

### Benchmarks, Datasets and Scoring

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `librispeech` | [LibriSpeech ASR corpus](https://www.openslr.org/12) | `required-public` | Clean/read-speech comparability and regression tracking. | Read speech is not representative of spontaneous hotkey dictation. |
| `earnings22` | [Earnings-22](https://github.com/revdotcom/speech-datasets/tree/main/earnings22) | `required-public` | Long-form, numbers, entities and business-domain speech. | Respect dataset terms and use its prescribed normalization. |
| `contextual-earnings22` | [Contextual Earnings-22](https://arxiv.org/abs/2604.07354) | `recommended` | Contextual entity and terminology evaluation beyond aggregate WER. | New benchmark; confirm artifact availability and license before CI use. |
| `tedlium3` | [TED-LIUM Release 3](https://www.openslr.org/51) | `required-public` | Prepared speech with natural prosody and varied speakers. | Not equivalent to close-mic dictation. |
| `gigaspeech` | [GigaSpeech](https://github.com/SpeechColab/GigaSpeech) | `recommended` | Large, diverse English ASR evaluation/training reference. | Use only permitted evaluation splits; full corpus is large. |
| `ami` | [AMI Meeting Corpus](https://groups.inf.ed.ac.uk/ami/corpus/) | `recommended` | Conversational speech, overlap and room acoustics. | Phase 1 does not perform target-speaker personalization; report overlap separately. |
| `musan` | [MUSAN](https://www.openslr.org/17) | `required-noise` | Music, speech and noise mixtures for controlled SNR evaluation. | Synthetic mixtures do not replace real device/environment recordings. |
| `sclite` | [NIST SCTK / sclite](https://github.com/usnistgov/SCTK) | `required-reference` | Canonical ASR scoring and alignment reference. | Document normalization so app metrics and public leaderboard metrics are not conflated. |

### Production/Open-Source App References

| ID | Source | Status | Use | Caveat |
|---|---|---|---|---|
| `openwhispr` | [OpenWhispr](https://github.com/OpenWhispr/openwhispr) | `reference` | Cross-platform local Parakeet/Whisper hotkey product patterns and packaging. | Do not infer undocumented proprietary-quality techniques from marketing claims. |
| `pindrop` | [Pindrop](https://github.com/watzon/pindrop) | `reference` | Native macOS menu-bar dictation, multiple local engines and streaming UX patterns. | Review licenses before copying code; architecture may differ from this app. |
| `typewhisper` | [TypeWhisper](https://github.com/TypeWhisper) | `reference` | Multi-engine on-device dictation and per-app profile patterns. | Use only publicly verifiable implementation details. |
| `opensuperwhisper` | [OpenSuperWhisper](https://github.com/Starmel/OpenSuperWhisper) | `reference` | macOS hotkeys, Whisper/Parakeet engine selection and recording UX. | Reference product mechanics, not accuracy claims. |
