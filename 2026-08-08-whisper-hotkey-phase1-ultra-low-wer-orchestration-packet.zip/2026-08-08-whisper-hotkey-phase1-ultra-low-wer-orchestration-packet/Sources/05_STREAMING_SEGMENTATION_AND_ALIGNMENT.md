# Streaming Segmentation And Alignment

The entries below are decision aids, not a license to copy claims without reproduction.

## Streaming and Semantic Segmentation

### Semantic Segmentation with Bidirectional Language Models Improves Long-form ASR

- **ID:** `semantic-segmentation`
- **Type/status:** `paper` / `adopt-principle`
- **URL:** https://arxiv.org/abs/2305.18419
- **Use for this project:** Sentence completeness can outperform pause-only segmentation while reducing WER and endpoint latency.
- **Caveat:** The app needs bounded local inference and deterministic commit rules, not unrestricted remote LM segmentation.

### Simul-Whisper: Attention-Guided Streaming Whisper with Truncation Detection

- **ID:** `simul-whisper`
- **Type/status:** `paper` / `design-reference`
- **URL:** https://arxiv.org/abs/2406.10052
- **Use for this project:** Cross-attention-guided chunking and explicit truncated-word detection for streaming Whisper.
- **Caveat:** Implement concepts compatible with the current helper; do not import an incompatible runtime wholesale.

## Timestamps and Alignment

### WhisperX: Time-Accurate Speech Transcription of Long-Form Audio

- **ID:** `whisperx-paper`
- **Type/status:** `paper` / `design-reference`
- **URL:** https://arxiv.org/abs/2303.00747
- **Use for this project:** VAD cut/merge, forced alignment and long-form word timing.
- **Caveat:** Forced alignment cannot fix lexical errors by itself and should not become the only source of confidence.

