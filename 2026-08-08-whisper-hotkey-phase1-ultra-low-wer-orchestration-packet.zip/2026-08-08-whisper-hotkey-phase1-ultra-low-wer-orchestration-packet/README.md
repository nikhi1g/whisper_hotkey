# whisper_hotkey Phase 1 Ultra-Low-WER Orchestration Packet

**Packet date:** 2026-08-08  
**Scope:** Phase 1 only  
**Sub-agent type:** `luna_worker`

## Audit conclusion

**Latest public release audited:** `v3.6.2` (`317fced`). Current `main` is ahead and is audited separately.

The requested architecture has **not** landed end to end in the current GitHub `main` branch. The repository has a useful adaptive Whisper retry, but recognition still collapses to strings. The app does not preserve provider-neutral word timings, calibrated per-word confidence, bounded original-audio verifier spans, deterministic candidate fusion, or a lexically invariant formatting layer.

The exact blockers and source URLs are in [`MD/02_CURRENT_REPOSITORY_AUDIT.md`](MD/02_CURRENT_REPOSITORY_AUDIT.md) and [`Sources/01_CURRENT_REPOSITORY_SOURCES.md`](Sources/01_CURRENT_REPOSITORY_SOURCES.md).

## Intended Phase 1 result

A local macOS dictation pipeline that:

1. runs the selected Parakeet or Whisper Turbo primary recognizer immediately;
2. preserves words, timestamps, alternatives and acoustic/decoder evidence;
3. estimates calibrated per-word error probability;
4. re-decodes only bounded uncertain spans from original audio with a stronger or complementary local verifier;
5. fuses candidates while locking already-correct words, numbers and names;
6. restores punctuation, capitalization and sentence boundaries without changing lexical content;
7. applies to press-and-hold, toggle, Pause Mode, Model Ready, Decode After Speaking and Decode While Speaking;
8. remains bounded, cancellation-safe, race-free and fast enough for interactive use.

## Claim boundary

The desired `WER <= 1%` is a **promotion target on a frozen, clean-and-recoverable application corpus**, with a documented normalizer and confidence interval. This packet does not claim that the current app or any single public model already achieves universal sub-1% WER.

## Packet map

- [`MD/00_ORCHESTRATOR_START_HERE.md`](MD/00_ORCHESTRATOR_START_HERE.md): integration owner instructions.
- `MD/01...22`: architecture, repository mapping, metrics and release gates.
- `MD/Workers/W00...W14`: isolated `luna_worker` assignments.
- [`Sources/00_SOURCE_INDEX.md`](Sources/00_SOURCE_INDEX.md): primary-source research/library index.
- `Sources/BIBLIOGRAPHY.bib`, `sources.json`, and freshness matrix: machine-readable references.
- `Miscellaneous/Algorithms`: deterministic algorithms and complexity bounds.
- `Miscellaneous/Schemas`: provider-neutral result, repair and benchmark contracts.
- `Miscellaneous/Scripts`: WER, paired bootstrap, lexical-invariance and packet-validation tools.
- `Miscellaneous/Diagrams`: Mermaid architecture and state diagrams.
- `Miscellaneous/Benchmarks`: evaluation protocol and corpus manifest.

## Orchestrator use

1. Check out the current repository and record the commit SHA.
2. Read `MD/00_ORCHESTRATOR_START_HERE.md` and repository `SUBAGENTS.md`.
3. Create isolated worktrees and branches for each `luna_worker` packet.
4. Freeze the benchmark and contracts before integrating a verifier model.
5. Merge only through the orchestrator after focused tests and paired benchmark evidence.
6. Run:

```bash
python3 Miscellaneous/Scripts/validate_packet.py
python3 Miscellaneous/Scripts/tests/test_metrics.py
```

## Non-goals

This packet does not include user-specific voice recognition, target-speaker isolation, persistent training data, personal acoustic adapters, continual/overnight training, or cloud transcription.
