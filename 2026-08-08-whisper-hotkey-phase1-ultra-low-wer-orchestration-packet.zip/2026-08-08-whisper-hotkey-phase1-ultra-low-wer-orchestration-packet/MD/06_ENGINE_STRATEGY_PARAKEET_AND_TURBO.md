# Engine Strategy: Parakeet and Whisper Turbo

## Principle

The selected engine remains the primary user-facing model. The accuracy layer may invoke a complementary verifier, but must not silently replace the user's configured engine for all audio.

## Parakeet primary

### Immediate provider work

- Preserve the complete FluidAudio result instead of `.text`.
- Confirm the exact 0.15.5 word/timing API with compile-time tests.
- Record offline vs streaming mode and seam/chunk provenance.
- Evaluate Unified 0.6B against TDT v2 on the application corpus.
- Use FluidAudio custom-vocabulary controls only where supported and benchmark false boosts.

### Preferred verifier order

1. Full-precision Whisper large-v3 on selective spans.
2. Current Turbo with a different decoding configuration, only as an ablation.
3. `parakeet.cpp` 1.1B TDT/hybrid on Metal, after parity/latency/licensing validation.
4. Qwen3-ASR 1.7B through an Apple-compatible runtime, experimental only.

A same-family larger Parakeet can improve raw accuracy, but a cross-family verifier often provides more useful disagreement diversity. Measure both.

## Whisper Turbo primary

### Immediate provider work

- Enable token and word timestamps.
- Return token log probabilities and all fallback metadata.
- Preserve N-best candidates where the API permits.
- Use bounded prompts for terminology/context, never unbounded previous text.
- Keep beam search and temperature fallback configurable for experiments.
- Stop using `-nt` in accuracy-capable paths.

### Preferred verifier order

1. Full Whisper large-v3, not Turbo, on uncertain spans. Turbo has only four decoder layers versus large-v3's 32, so the full model is a rational accuracy verifier.
2. Parakeet Unified/TDT on ANE as a complementary hypothesis.
3. Parakeet 1.1B through `parakeet.cpp`/MLX if local benchmarks justify the added footprint.
4. Qwen3-ASR 1.7B only after proving macOS deployment feasibility and actual repair precision.

## Do not assume model-card ranking transfers

Model cards use different corpora, normalization, runtimes, and hardware. The repository's own 100-utterance benchmark is also too small. Every candidate must run on the same frozen corpus with identical scoring.

## Candidate experiment matrix

| Primary | Verifier | Expected value | Main risk |
|---|---|---|---|
| Parakeet Unified 0.6B | Whisper large-v3 | Cross-family corrections, strong context | Large Metal footprint |
| Parakeet TDT v2 | Whisper large-v3 | Same as above, higher English recall primary | punctuation/timing integration |
| Turbo Q5 | full large-v3 F16/F32 | Stronger same-family decoder | GPU contention, model size |
| Turbo Q5 | Parakeet Unified | Heterogeneous ANE/Metal execution | timing/alignment mismatch |
| Parakeet 0.6B | Parakeet 1.1B | Larger same-family verifier | correlated errors |
| Either | Qwen3-ASR 1.7B | strong alternate model family | runtime maturity and memory |

## Model residency

- Decode After Speaking: do not keep a large verifier resident by default.
- Model Ready: optionally preload verifier only when memory policy permits.
- Decode While Speaking: preload a verifier only when it stays faster than the sentence finalization budget.
- Always expose model download size and expected peak memory before enabling an optional verifier.
