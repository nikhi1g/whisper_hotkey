# luna_worker Task: Provider-Neutral Rich Recognition Contracts

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** Immediately.

## Desired result

Provider-Neutral Rich Recognition Contracts completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- Core recognition contract files
- new contract tests
- protocol schema docs


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Design and implement stable word IDs, words, segments, alternatives, evidence, timing, completeness, provenance, and model identity.
2. Provide migration adapters so current text behavior remains unchanged.
3. Define protocol-v2 JSON schema and bounded decoding limits.
4. Add Codable/Sendable/equality and malformed-input fixtures.


## Must not do

- Do not edit provider internals except compile adapters.
- No confidence thresholds in the contract layer.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- contract API rationale
- source changes
- unit tests
- migration notes
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
