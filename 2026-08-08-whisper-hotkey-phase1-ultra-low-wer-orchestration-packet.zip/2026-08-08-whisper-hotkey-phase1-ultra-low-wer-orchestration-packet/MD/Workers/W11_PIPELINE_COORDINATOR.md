# luna_worker Task: Actor-Owned Three-Layer Pipeline Coordinator

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W04/W05/W07/W08/W09 interfaces are accepted.

## Desired result

Actor-Owned Three-Layer Pipeline Coordinator completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- app orchestration/coordinator files
- integration tests


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Implement the staged DAG with one canonical word state.
2. Run punctuation and verifier work concurrently after primary words exist.
3. Own deadlines, backpressure, generation, cancellation, model leases, and one final delivery.
4. Fallback to guarded primary on enhancement failure.
5. Support every activation/processing combination.


## Must not do

- Do not redesign provider contracts unilaterally.
- No direct paste from sublayers.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- integration implementation
- task/cancellation diagram
- mode matrix tests
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
