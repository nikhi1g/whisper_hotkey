# luna_worker Task: Baseline, Repository Verification, and Reproduction

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** Immediately.

## Desired result

Baseline, Repository Verification, and Reproduction completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- benchmark scripts and fixtures
- documentation-only audit output
- no production recognition source unless explicitly assigned


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Pin current commit, release, Swift/FluidAudio/whisper.cpp versions, model checksums, macOS, and hardware.
2. Reproduce current benchmark and all mode smoke tests.
3. Create machine-readable baseline JSONL and a concise audit diff against `MD/02_CURRENT_REPOSITORY_AUDIT.md`.
4. Identify exact existing benchmark commands and missing corpus hooks.


## Must not do

- Do not change recognition behavior.
- Do not tune thresholds using test labels.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- baseline report
- reproduction command(s)
- raw JSONL/CSV schema
- list of audit facts confirmed/changed
- commit SHA and tests

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
