# luna_worker Task: Selective Verifier Model Experiments

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W00 runner exists.

## Desired result

Selective Verifier Model Experiments completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- experiment harness and benchmark config
- decision documentation
- no production coordinator paths


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Benchmark existing cross-engine verification first.
2. Evaluate full Whisper large-v3, parakeet.cpp 1.1B/hybrid, and optional Qwen3-ASR 1.7B on bounded spans.
3. Measure error-set overlap, oracle repair, actual guarded repair, p50/p95, peak RSS, cold/warm load, and Apple Silicon contention.
4. Produce a pinned verifier decision, not an unbounded model wishlist.


## Must not do

- Do not integrate a candidate before results.
- Do not claim model-card WER as application WER.
- Check licenses and distribution footprint.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- verifier_decision.md
- raw benchmark results
- model checksums/versions
- rejected-candidate rationale
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
