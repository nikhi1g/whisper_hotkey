# luna_worker Task: Punctuation, Capitalization, and Boundary Layer

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W01 stable word IDs exist.

## Desired result

Punctuation, Capitalization, and Boundary Layer completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- new formatting module/tests
- formatting benchmark scripts


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Implement label-only punctuation/case/boundary output on stable words.
2. Use bounded lookahead and pause/prosody/semantic-completeness evidence.
3. Implement lexical invariance proof and fail-closed behavior.
4. Test thinking pauses, questions, names, acronyms, fragments, and final stop.


## Must not do

- Never generate replacement lexical text.
- No user-specific personalization.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- model/scorer decision
- formatting metrics
- lexical mutation tests
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
