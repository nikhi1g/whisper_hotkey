# luna_worker Task: Apple Silicon Performance, Memory, and Reliability

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W00 baseline exists.

## Desired result

Apple Silicon Performance, Memory, and Reliability completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- profiling scripts/tests/docs
- small performance-policy source only if assigned


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Profile M5 Pro 24 GB and define a lower-memory Mac matrix.
2. Compare ANE+Metal heterogeneity against same-device overlap/sequential execution.
3. Measure model residency, peak RSS, xctrace/Instruments traces, cancellation, soak behavior, and thread oversubscription.
4. Propose deterministic backpressure and thermal fallback policy.


## Must not do

- Do not lower primary accuracy silently.
- Do not rely on processor-count intuition without profiling.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- profile report
- recommended concurrency policy
- leak/soak results
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
