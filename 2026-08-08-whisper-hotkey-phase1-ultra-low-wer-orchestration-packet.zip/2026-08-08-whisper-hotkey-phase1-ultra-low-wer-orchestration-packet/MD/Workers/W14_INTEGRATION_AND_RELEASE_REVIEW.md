# luna_worker Task: Final Integration, Adversarial Review, and Release Gates

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After all branches are available.

## Desired result

Final Integration, Adversarial Review, and Release Gates completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- integration branch review, tests, docs; no independent feature redesign


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Audit all invariants and owned-path conflicts.
2. Run full benchmark/ablation/mode/soak/cancel matrix.
3. Verify no Phase 2 code or persistence entered.
4. Verify docs match code and optional model footprint is disclosed.
5. Exercise primary-only rollback and enhancement failure paths.


## Must not do

- Do not waive failed gates for demo quality.
- Do not claim <1% outside the exact measured track.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- release review
- gate table
- known limitations
- rollback proof
- final commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
