# luna_worker Task: Decode-While-Speaking and Pause-Mode Sentence Stability

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W01/W04 accepted.

## Desired result

Decode-While-Speaking and Pause-Mode Sentence Stability completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- background predecode and mode-specific accumulation files/tests


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Replace `[String]` joining with timed-word overlap reconciliation.
2. Maintain stable prefix plus revisable tail.
3. Separate decode, punctuation, semantic endpoint, and paste boundaries.
4. Commit whole stable sentences in Pause Mode and one final ordered transcript in deferred modes.
5. Guarantee final tail and fallback decode.


## Must not do

- Do not paste from provider tasks.
- Do not use every pause as a period.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- mode diagrams
- boundary stress tests
- latency/revision metrics
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
