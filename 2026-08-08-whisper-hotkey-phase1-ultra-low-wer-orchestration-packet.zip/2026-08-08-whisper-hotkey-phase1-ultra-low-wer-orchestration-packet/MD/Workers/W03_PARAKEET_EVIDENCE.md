# luna_worker Task: Parakeet/FluidAudio Rich Result Preservation

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W01 interface is accepted.

## Desired result

Parakeet/FluidAudio Rich Result Preservation completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- `Sources/WhisperHotkeyASR/ParakeetRuntime.swift`
- Parakeet-specific adapter/tests


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Inspect the exact FluidAudio 0.15.5 API at compile time.
2. Preserve word/token timings, segment boundaries, seam/chunk provenance, model/mode metadata, and available score evidence.
3. Represent unavailable confidence explicitly rather than fabricating it.
4. Test Accurate, Fast, and Unified variants where repository selection supports them.


## Must not do

- Do not add speaker diarization or personalization.
- Do not replace FluidAudio without benchmark evidence.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- API evidence matrix
- adapter implementation
- fixtures/tests
- variant behavior report
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
