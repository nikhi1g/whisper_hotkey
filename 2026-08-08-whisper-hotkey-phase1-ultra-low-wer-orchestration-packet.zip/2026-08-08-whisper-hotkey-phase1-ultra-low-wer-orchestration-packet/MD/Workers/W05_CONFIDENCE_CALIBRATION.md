# luna_worker Task: Word Error Probability and Calibration

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W02/W03 fixtures exist.

## Desired result

Word Error Probability and Calibration completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- new confidence module
- calibration/benchmark scripts
- confidence tests


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Implement feature extraction for available provider evidence.
2. Establish raw probability, entropy, temperature scaling, isotonic/logistic, and disagreement baselines.
3. Calibrate per engine/model/profile on held-out data.
4. Report PR-AUC, ECE, MCE, NCE, error recall at verifier budgets, and false unlock rate.


## Must not do

- Do not tune on the final test set.
- Do not use one universal confidence threshold without evidence.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- calibration artifacts
- model/threshold versioning plan
- metrics report
- unit/property tests
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
