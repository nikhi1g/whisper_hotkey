# luna_worker Task: Timestamp-Aware Fusion, MBR/ROVER, and Lexical Safety

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W02/W03 fixtures exist.

## Desired result

Timestamp-Aware Fusion, MBR/ROVER, and Lexical Safety completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- alignment/fusion modules/tests


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Implement bounded timestamp-aware DP alignment.
2. Implement deterministic pairwise baseline, weighted ROVER/confusion network, and MBR/medoid experiment path.
3. Protect locked anchors and stricter semantic classes.
4. Reject edits outside authorized spans or without minimum evidence margin.


## Must not do

- No free-form LLM correction.
- Do not alter punctuation as part of lexical fusion unless it is provider provenance only.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- fusion benchmarks
- repair decision reason codes
- safety/property tests
- complexity bounds
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
