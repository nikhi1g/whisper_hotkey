# luna_worker Task: Whisper Helper Evidence and Timestamp Preservation

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** After W01 interface is accepted.

## Desired result

Whisper Helper Evidence and Timestamp Preservation completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- `Sources/WhisperModelHelper/**`
- Whisper-specific ASR adapter files/tests


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Emit protocol-v2 rich results with token/word timing, log probabilities, no-speech, repetition, decoding strategy, beam/fallback metadata, and alternatives where supported.
2. Stop disabling timestamps in accuracy-capable fallback paths.
3. Deserialize and preserve evidence in Swift.
4. Keep protocol-v1 compatibility during migration.


## Must not do

- Do not implement fusion or punctuation.
- Do not make whole-utterance beam fallback the final selective-repair design.
- Do not log transcript/audio.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- helper protocol fixtures
- C++ and Swift tests
- evidence-availability matrix
- latency delta
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
