# luna_worker Task: Expanded Frozen Benchmark and Scoring

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** Immediately.

## Desired result

Expanded Frozen Benchmark and Scoring completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- benchmark tooling/data manifests/tests
- no product behavior paths


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Preserve existing 100-utterance smoke benchmark.
2. Add full/public tracks and an application-corpus manifest.
3. Implement frozen normalized/display WER, CER, entity/number/homophone, punctuation, boundary, confidence, repair, latency, and memory schemas.
4. Add paired bootstrap confidence intervals and ablation reporting.


## Must not do

- Do not redistribute restricted datasets.
- Do not include ordinary user recordings.
- Do not alter normalization after seeing test outcomes.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- runner commands
- schemas
- dataset/license manifest
- statistical tests
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
