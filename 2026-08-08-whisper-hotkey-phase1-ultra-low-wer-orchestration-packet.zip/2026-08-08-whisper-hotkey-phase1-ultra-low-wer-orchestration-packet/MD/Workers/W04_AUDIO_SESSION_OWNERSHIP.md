# luna_worker Task: Canonical Audio Lease and Cleanup Ownership

## Assignment

Spawn this task using the sub-agent type **`luna_worker`** in an isolated worktree and dedicated branch.

**Dependency:** Immediately.

## Desired result

Canonical Audio Lease and Cleanup Ownership completed as the smallest end-to-end change that advances the Phase 1 architecture without implementing Phase 2 personalization.

## Owned paths

The orchestrator must convert these categories into exact non-overlapping repository paths before spawning:

- audio file/lifecycle source files
- new audio lease implementation/tests


Do not edit outside the assigned paths without stopping and returning a path-conflict request to the orchestrator.

## Required work

1. Move deletion responsibility out of individual recognizers.
2. Implement session-owned canonical audio with immutable bounded span views.
3. Guarantee exactly-once cleanup after all child tasks complete/cancel.
4. Add rapid cancel/start/stop/model-switch tests and file-permission checks.


## Must not do

- Do not persist audio beyond active session.
- Do not introduce transcript/audio logging.

- Do not add cloud calls, audio/transcript logging, or persistent user corpus storage.
- Do not implement target-speaker recognition or user-specific model training.
- Do not change unrelated UI.

## Required verification

- Add focused unit tests for new deterministic logic.
- Run the narrowest relevant existing test targets.
- Add one failure/cancellation/boundary test when the task touches async or audio lifecycle code.
- Report runtime, memory, and benchmark impact when the task changes inference.
- Keep fixtures synthetic or licensed/consented.

## Read before starting

- `../00_ORCHESTRATOR_START_HERE.md`
- `../03_CANONICAL_THREE_LAYER_ARCHITECTURE.md`
- `../19_DEFINITION_OF_DONE.md`
- the task-relevant design file in `MD/`
- `../../Sources/00_SOURCE_INDEX.md`
- repository `SUBAGENTS.md`

## Return to orchestrator

- lifetime state diagram
- source changes
- race/cleanup tests
- failure analysis
- commit SHA

- exact files changed;
- unresolved assumptions and follow-up dependencies.

Do not merge your own branch.
