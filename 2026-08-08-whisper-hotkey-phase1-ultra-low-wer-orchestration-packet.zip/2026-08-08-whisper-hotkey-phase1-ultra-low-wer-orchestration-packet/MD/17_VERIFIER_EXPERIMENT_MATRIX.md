# Verifier Experiment Matrix

## Required question

Which local verifier corrects the most primary errors per millisecond and per gigabyte **without introducing false rewrites**?

## Experiment stages

### Stage 1: no new dependency

Use the existing alternate engine as verifier:

- Parakeet primary -> current Turbo Q5 selective spans.
- Turbo primary -> Parakeet Accurate/Unified selective spans.

This establishes whether cross-family disagreement is valuable before adding model footprint.

### Stage 2: full Whisper large-v3

Test full, non-Turbo large-v3 because Turbo is a pruned four-decoder-layer version of large-v3. Use selective spans only. Compare quantized and full-precision variants available in the chosen runtime.

### Stage 3: larger Parakeet

Evaluate `parakeet.cpp` 1.1B TDT and hybrid TDT-CTC with Metal. Validate:

- transcript parity claims against original NeMo checkpoints on supplied tests;
- Apple Silicon speed and memory on the target Mac;
- timing/confidence/N-best API maturity;
- model license and redistribution implications;
- static/shared-library integration complexity.

### Stage 4: Qwen3-ASR 1.7B

Experimental. Test only if an Apple-compatible local runtime can meet memory/latency and licensing requirements. It may provide useful model-family diversity and complex-acoustic robustness.

## Per-candidate measurements

- standalone normalized WER/CER;
- oracle repair rate on primary errors;
- overlap of error sets with primary;
- actual guarded repair precision/recall;
- high-confidence corruption;
- span and whole-sentence latency;
- warm/cold startup;
- peak RSS and Metal/ANE contention;
- model/download size;
- timestamp and evidence quality;
- integration/build/distribution risk.

## Decision score

Do not collapse everything into one opaque score for the final report, but a ranking aid may use:

```text
utility = corrected_reference_errors
        - 5 * introduced_errors
        - latency_penalty
        - memory_penalty
        - integration_risk_penalty
```

Introduced errors receive a much larger penalty than missed opportunities.

## Required output

`verifier_decision.md` must state:

- selected verifier(s);
- rejected candidates and evidence;
- exact model/runtime versions and checksums;
- supported Macs and residency policy;
- fallback behavior;
- benchmark tables and raw JSONL path.
