# Canonical Three-Layer Architecture

## System model

Let the source audio be `x`, the primary recognizer be `P`, confidence estimator be `C`, verifier be `V`, fusion policy be `G`, and formatting model be `F`.

```text
R0 = P(x)
q  = C(R0, primary evidence, audio features)
S  = merge_and_pad({word_i | q_i >= threshold})
RV = V(x[S], context)
R1 = G(R0, RV, locked anchors, calibration)
Y  = F(R1.words, timing/prosody/context)
```

`Y` may differ lexically from `R0` only inside the explicitly unlocked spans `S`, and only when the verifier/fusion policy passes the evidence threshold. Formatting may not change the lexical sequence at all.

## Layer 1: Primary recognition

### Inputs

- canonical session audio or sentence-scale audio view;
- selected engine and model;
- decoding mode;
- bounded prior context where the engine supports it;
- session ID and generation.

### Outputs

- stable ordered word IDs;
- word text;
- start/end times;
- token spans or alignment provenance;
- raw and normalized confidence features;
- N-best/alternate candidates when available;
- no-speech/repetition/truncation evidence;
- engine/model/precision/decoding metadata;
- segment boundaries and completeness state.

### Requirement

The baseline text should be usable immediately, but not yet pasted by lower layers.

## Layer 2: Selective accuracy

### Confidence

Estimate `P(word incorrect | evidence)` rather than interpreting raw softmax probability as truth. Use temperature/isotonic calibration on held-out data and report calibration metrics.

Candidate features may include:

- token posterior and entropy;
- minimum/mean token confidence within a word;
- beam score and rank dispersion;
- N-best disagreement;
- cross-engine disagreement;
- neighboring word evidence;
- no-speech probability;
- repetition/hallucination flags;
- audio SNR/clipping/VAD boundary proximity;
- word duration anomalies;
- truncation likelihood.

### Span planner

- Convert uncertain word IDs into time spans using word timings.
- Merge nearby spans.
- Add configurable left/right acoustic padding.
- Add text context without allowing it to overwrite acoustics.
- Enforce maximum span duration, total verifier-audio ratio, and span count.

### Verifier

The verifier is deliberately stronger or complementary:

- Whisper Turbo primary -> full Whisper large-v3 or Parakeet 1.1B/Unified verifier.
- Parakeet primary -> full Whisper large-v3 verifier first; larger Parakeet or Qwen3-ASR only after measured experiments.

Run it only on suspect spans unless a whole-session fallback is triggered by catastrophic evidence.

### Fusion

- Align primary and verifier word sequences by time plus dynamic programming.
- Build a bounded confusion network where useful.
- Use calibrated system/word evidence or MBR/medoid risk to choose candidates.
- Preserve locked anchors.
- Reject edits that change protected numbers, units, negation, or named entities without stronger audio evidence.
- Record reason codes for every accepted/rejected repair in benchmark builds, never audio/transcript content in production logs.

## Layer 3: Lexically invariant formatting

The formatting layer receives canonical word IDs and predicts labels on boundaries:

```text
word_1 [NONE|COMMA|PERIOD|QUESTION|EXCLAMATION|COLON|SEMICOLON]
word_2 ...
```

It may also predict casing classes for existing lexical tokens. It must not generate free-form text.

Inputs should include:

- bounded left/right word context;
- pause duration and normalized pause statistics;
- pitch/energy continuation cues where available;
- ASR segment-boundary/truncation evidence;
- syntactic/semantic completeness score;
- mode-specific finality signal.

A pause alone is not a sentence boundary. Final punctuation requires lexical/prosodic support or final end-of-dictation.

## Coordinator

A `RecognitionPipelineCoordinator` actor owns:

- session/generation identity;
- canonical audio lease;
- primary and verifier model leases;
- canonical word graph;
- lock/unlock state;
- task deadlines and cancellation;
- final text assembly;
- one ordered delivery event.

No provider, verifier, formatter, or worker task pastes text directly.

## Compute topology on Apple Silicon

Benchmark rather than assume the best mapping. Starting hypotheses:

- Parakeet/Core ML on ANE as primary, full Whisper large-v3 on Metal as selective verifier, punctuation on CPU/ANE.
- Whisper Turbo on Metal as primary, Parakeet/Core ML on ANE as complementary verifier, punctuation on CPU/ANE.
- Avoid two simultaneous large Metal models unless profiling proves a latency win.
- Preload the optional verifier only in Model Ready/Decode While Speaking or after repeated uncertainty justifies it.

## Complexity

Let `T` be audio duration, `W` word count, `U` total uncertain audio duration, and bounded candidate lengths `n,m`.

- primary decode: model-dependent, approximately linear in `T` for the application budget;
- confidence and formatting: `O(W)`;
- selective verifier: proportional to `U`, with `U << T` under normal conditions;
- bounded pairwise alignment: `O(nm)` only within capped spans;
- memory: canonical audio plus bounded word/candidate graphs, no unbounded per-chunk transcript history.
