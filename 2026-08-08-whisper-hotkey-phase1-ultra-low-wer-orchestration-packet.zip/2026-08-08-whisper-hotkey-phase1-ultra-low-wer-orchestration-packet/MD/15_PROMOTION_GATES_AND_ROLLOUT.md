# Promotion Gates and Rollout

## Hard safety gates

A build cannot advance if any is true:

- formatting changes lexical words;
- a repair changes a locked word;
- stale/cancelled results can paste;
- source audio can be deleted while a task uses it;
- queue, candidate, span, or prompt growth is unbounded;
- production logs contain audio/transcript text;
- selected engine silently falls back to another engine;
- network access is introduced into transcription.

## Accuracy gates

Tune numeric thresholds from the frozen benchmark, then record them in release configuration. Recommended policy form:

- application normalized WER shows statistically supported improvement;
- clean-and-recoverable target may be <=1%, but no release claim until measured;
- public-corpus aggregate does not materially regress;
- repair precision >= 98% on the application test set;
- high-confidence word corruption <= 0.05% of reference words;
- number/unit/negation regression count = 0 on protected safety cases;
- punctuation and boundary F1 improve or remain within a small non-inferiority margin;
- lexical mutation by formatting = 0.

## Latency and resource gates

- Decode After Speaking/Model Ready final p95 within the agreed few-second ceiling;
- Decode While Speaking remains faster than real time and stable-sentence commit meets UX budget;
- no growing RSS across a long start/stop/cancel soak test;
- no helper/model process leak;
- no thermal runaway that increases sustained p95 beyond the fallback policy.

## Rollout stages

1. Hidden benchmark-only feature flag.
2. Developer opt-in with detailed local diagnostics.
3. Small beta using content-free metrics and explicit report export.
4. Default on for supported hardware/configurations only after promotion gates.
5. Keep instant rollback to primary-only pipeline.

## Fallback hierarchy

- verifier timeout/failure -> guarded primary result;
- confidence unavailable -> conservative provider-specific heuristic or no repair;
- formatter failure -> provider punctuation or deterministic minimal formatting;
- memory pressure -> sequentialize models, reduce verifier coverage;
- never return an empty result solely because an enhancement failed.
