# Candidate Fusion and Lexical Safety

## Goal

Choose the most audio-supported candidate without allowing a language model or formatter to rewrite correct speech.

## Candidate sources

- primary 1-best;
- primary N-best;
- stronger verifier 1-best/N-best;
- complementary engine hypothesis;
- forced-alignment-compatible word candidates;
- contextual vocabulary only when it appears among acoustically plausible candidates.

## Alignment

Use timestamp-aware dynamic programming. Cost should consider:

- normalized lexical edit cost;
- time overlap;
- phonetic similarity where available;
- locked anchors;
- provider confidence;
- insertion/deletion gap evidence.

Build a small confusion network per repair span. Do not construct an unbounded session-wide lattice.

## Selection methods

Implement in increasing sophistication:

1. calibrated pairwise replacement rules;
2. weighted ROVER voting over aligned words;
3. MBR/medoid selection over complete span candidates using expected WER-like loss;
4. optional learned rescoring after deterministic baselines.

Every method must be benchmarked against simply keeping the primary result.

## Locked anchors

Words remain locked when:

- calibrated error probability is below the strict threshold;
- timing is stable;
- primary and verifier agree;
- no deletion-gap evidence touches the word.

The fusion algorithm may use locked anchors to align a span but may not alter them.

## Protected semantic classes

Use stricter acceptance for:

- numbers and decimal points;
- dates and times;
- units and dosages;
- negation;
- names and identifiers;
- URLs, file paths, code symbols, and acronyms.

A contextual preference is insufficient. Require acoustic/cross-model evidence and a minimum margin.

## Repair decision record

Benchmark builds should emit content-free metadata:

```json
{
  "span_id": "...",
  "decision": "accepted|rejected|timeout",
  "reason": "cross_model_agreement|mbr_margin|anchor_violation|...",
  "primary_score": 0.0,
  "candidate_score": 0.0,
  "margin": 0.0,
  "words_unlocked": 2,
  "words_changed": 1
}
```

Production logs must not include audio or transcript text.

## Final guard

After fusion:

- verify timestamp order;
- verify locked words unchanged;
- verify edits are contained within authorized spans;
- verify no duplicated overlap text;
- verify no empty result when primary was non-empty;
- reject candidate if any invariant fails.
