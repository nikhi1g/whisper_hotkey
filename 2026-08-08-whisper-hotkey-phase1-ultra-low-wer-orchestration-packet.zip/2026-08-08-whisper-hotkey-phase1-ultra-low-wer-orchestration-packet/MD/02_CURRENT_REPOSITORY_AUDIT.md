# Current Repository Audit

**Audit date:** 2026-08-08  
**Branch inspected:** GitHub `main` via raw source endpoints  
**Latest public release inspected:** `v3.6.2` (`317fced`), released 2026-08-07  
**Package baseline:** Swift 6, macOS 14, FluidAudio pinned exactly to 0.15.5

## Release versus main boundary

The latest public release visible during this audit is `v3.6.2`, commit `317fced`. Current `main` is ahead of that release. The orchestrator must record whether implementation starts from the release tag or current `main`, reproduce both when behavior differs, and never attribute a `main` benchmark or feature to the shipped release without verification.

## Conclusion

The prior design advice did not land as an end-to-end implementation. The repository contains a useful Smart Decode fallback for Whisper, but it remains utterance-level and string-only. It cannot support calibrated per-word confidence, selective original-audio repair, cross-engine candidate fusion, or lexically guarded punctuation.

## Blocking findings

### 1. Recognition contracts are string-only

`Sources/WhisperHotkeyASR/WhisperRecognition.swift` exposes:

- `WhisperHelperEvent.case result(String)`;
- `transcribe(...) async throws -> String`;
- `transcribeChunk(...) async throws -> String`.

The helper envelope decodes only event/text/error fields. Any token evidence emitted by the helper has nowhere to go.

### 2. Whisper timestamps are disabled on fallback

`WhisperCommandLineInvocation.arguments` adds `-nt`. Without word or segment timings, an accuracy layer cannot map an uncertain word back to a bounded section of source audio.

### 3. Source audio lifetime ends inside the recognizer

The private Whisper `transcribe` function executes `defer { audio.delete() }`. A verifier, formatter using prosody, or fallback branch cannot safely share that file after the first provider returns. Audio ownership must move to a session-level lease.

### 4. Parakeet rich output is discarded

`Sources/WhisperHotkeyASR/ParakeetRuntime.swift` calls FluidAudio and returns only result text. FluidAudio 0.15.5 has word-level timestamp and unified-ASR work that the app is not preserving.

### 5. Smart Decode is not selective repair

`Sources/WhisperModelHelper/main.cpp` computes aggregate values such as average token log probability, weak-token fraction, no-speech probability, and repetition. The adaptive strategy runs a greedy decode and, when the utterance appears uncertain, re-runs the whole utterance with beam search. It does not expose calibrated word confidence or re-decode only suspect spans.

### 6. Helper evidence is discarded by Swift

Even when the C++ helper emits additional aggregate fields, `WhisperHelperProtocol.EventEnvelope` ignores them. The current Swift layer returns only cleaned text.

### 7. Decode While Speaking stores independent strings

`Sources/WhisperHotkeyCore/BackgroundPredecode.swift` accumulates `[String]` and joins them with spaces. Stable word identity, overlap reconciliation, revisable tails, confidence, and sentence-boundary evidence are lost.

### 8. Current architecture requires one serial recognition chain

`docs/ARCHITECTURE.md` intentionally serializes chunk recognition to preserve order. That is correct for delivery, but the new design needs internal task parallelism behind a single ordered coordinator rather than multiple direct paste paths.

### 9. Current benchmark is insufficient for a <1% claim

`docs/MODELS.md` reports 100 LibriSpeech utterances split between test-clean and test-other. It is useful as a smoke benchmark, but too small and too unlike spontaneous hotkey dictation to establish a sub-1% product claim.

## Existing strengths to retain

- Native Swift/AppKit architecture.
- Explicit process ownership and generation-based stale-result rejection.
- Private 16 kHz mono WAV contract.
- Local-only recognition.
- Model-ready lifecycle.
- Bounded Pause Mode and Decode While Speaking segmentation.
- Whisper prompt support.
- FluidAudio/ANE and whisper.cpp/Metal hardware diversity.
- Existing focused test targets and repository `SUBAGENTS.md` discipline.

## Immediate implication

Do not begin with a larger verifier model. First establish:

1. rich provider-neutral result contracts;
2. stable word/timing identity;
3. session-owned canonical audio;
4. benchmark and telemetry contracts.

Without these, an expensive verifier will merely produce a second string that cannot be safely aligned or selectively applied.
