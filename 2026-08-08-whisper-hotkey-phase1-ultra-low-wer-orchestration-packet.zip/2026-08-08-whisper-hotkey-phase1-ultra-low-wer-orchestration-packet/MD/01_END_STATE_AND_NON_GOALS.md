# End State and Non-Goals

## User-visible end state

The user presses or holds the configured hotkey, speaks naturally, and stops. Text appears in the original focused application with:

- lexical content matching the speech;
- correct homophone choice where audio and context distinguish it;
- proper capitalization of sentence starts, names, products, and acronyms;
- natural commas, question marks, and sentence boundaries;
- no period inserted merely because the user paused to think;
- no duplicated or dropped words at chunk boundaries;
- no visible engine switching or manual cleanup workflow;
- a normal completion time that feels immediate, with difficult cases resolved within a few seconds.

## Accuracy objective

The program should seek an application-specific normalized WER at or below 1% on a frozen, clean-and-recoverable dictation subset. This is an **acceptance target**, not a universal claim. Report broader results separately for noise, accents, far-field speech, music, long-form speech, and truncated/overlapping boundaries.

## Three conceptual layers

### 1. Primary recognition layer

- Runs the selected user-facing model: Parakeet or Whisper Turbo.
- Produces stable word records, timing, raw model evidence, alternatives, and model metadata.
- Returns a usable baseline quickly.

### 2. Selective accuracy layer

- Estimates probability of word error.
- Groups only suspect words into bounded, padded original-audio spans.
- Re-decodes those spans with a larger or complementary verifier.
- Chooses among acoustically generated candidates using calibrated evidence, ROVER/confusion-network alignment, or MBR-style risk.
- Locks high-confidence anchor words against casual rewriting.

### 3. Formatting layer

- Scores punctuation, capitalization, and sentence boundaries on stable word IDs.
- Uses bounded lexical context, pause/prosody evidence, and grammatical completeness.
- Cannot insert, delete, substitute, or reorder lexical words.
- Fails closed when lexical invariance cannot be proven.

## Why the layers are not fully parallel

The punctuation model and verifier can execute concurrently **after** the primary result exposes stable words. Confidence and uncertain-span selection cannot precede the primary hypothesis. Parallelize independent work, preloading, and heterogeneous hardware placement, but keep one actor-owned canonical state.

## Non-goals

- A general-purpose text editor or style rewriter.
- “Cleaning up” what the user meant instead of transcribing what they said.
- Fixing acoustically unrecoverable audio by hallucinating plausible words.
- Guaranteeing 100% accuracy.
- Running all models on all audio regardless of uncertainty.
- Using punctuation output as authority to alter lexical words.
- Training or adapting models to a particular user's voice in this phase.
- Trading correctness for benchmark-only normalization tricks.
