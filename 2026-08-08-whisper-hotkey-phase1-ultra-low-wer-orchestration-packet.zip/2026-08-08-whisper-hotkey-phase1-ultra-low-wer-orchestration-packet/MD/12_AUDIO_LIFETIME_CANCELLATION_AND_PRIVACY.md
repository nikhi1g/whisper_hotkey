# Audio Lifetime, Cancellation, and Privacy

## Current blocker

The recognizer currently deletes its audio argument in a `defer`. That ownership model is incompatible with concurrent confidence, verifier, prosody, and fallback tasks.

## Canonical audio lease

Introduce a session-owned `AudioLease` or equivalent:

- owns the private session directory and canonical WAV;
- vends immutable bounded audio views/spans;
- tracks active holders or is released only by the coordinator after child completion;
- deletes all session files exactly once;
- supports immediate cancellation while preventing use-after-delete;
- never persists beyond the active session in Phase 1.

## Rules

- Providers do not delete caller-owned audio.
- Span materialization is bounded and cleaned with the session.
- Prefer sample-range views or one canonical file over many copied WAVs when APIs allow it.
- Temporary files remain mode 0600 in a mode 0700 directory.
- No audio or transcript content enters logs, analytics, crash annotations, or network requests.

## Cancellation invariants

- New session cannot receive old results.
- Model switch invalidates all pending work.
- Cancel suppresses paste and submit.
- Helper termination cannot race with a new helper lease.
- Audio deletion waits for all child tasks or force-cancels them and confirms termination.
- A timed-out verifier cannot mutate canonical text later.

## Failure fallback

- Primary failure: use existing error behavior; do not invent text.
- Verifier failure/timeout: preserve primary result.
- Formatting failure: apply conservative deterministic punctuation or preserve provider punctuation.
- Benchmark instrumentation failure: never block transcription.
