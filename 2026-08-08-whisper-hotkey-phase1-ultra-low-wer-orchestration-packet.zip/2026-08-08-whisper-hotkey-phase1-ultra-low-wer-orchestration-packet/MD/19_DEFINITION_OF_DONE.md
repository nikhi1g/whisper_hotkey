# Definition of Done

## Architecture

- [ ] No provider-facing recognition API returns only `String` internally.
- [ ] Both Whisper and Parakeet produce rich provider-neutral results.
- [ ] Canonical audio is session-owned and survives all enhancement tasks.
- [ ] One coordinator owns canonical words and final delivery.
- [ ] Selective verification uses original audio and bounded spans.
- [ ] Formatting is lexically invariant.
- [ ] Phase 2 personalization is absent.

## Accuracy

- [ ] Frozen baseline and candidate reports exist.
- [ ] Confidence is calibrated per engine/model/profile.
- [ ] Repair precision and high-confidence corruption meet gates.
- [ ] WER/CER improve with paired confidence intervals.
- [ ] Homophone, proper noun, number/unit, and deletion tests pass.
- [ ] `<1% WER` is claimed only on the exact track where measured.

## Modes

- [ ] Press and Hold, Toggle, and Pause Mode pass.
- [ ] Decode After Speaking, Model Ready, and Decode While Speaking pass.
- [ ] Every supported combination has at least one end-to-end test.
- [ ] Pause Mode commits whole stable sentences, not arbitrary strings.
- [ ] Decode While Speaking reconciles overlaps and final tail.

## Reliability

- [ ] Rapid start/stop/cancel/model-switch stress tests pass.
- [ ] No stale insertion.
- [ ] No audio/helper/temp-file leak.
- [ ] No memory growth in soak test.
- [ ] Model calls respect reentrancy constraints.
- [ ] Enhancement timeout returns the primary transcript.

## Performance

- [ ] p50/p95/p99 reported on M5 Pro 24 GB.
- [ ] At least one lower-memory Apple Silicon profile reported.
- [ ] Peak RSS, RTF, warm/cold latency, and energy/thermal notes recorded.
- [ ] Verifier coverage is bounded and measured.
- [ ] Concurrent placement outperforms or is disabled in favor of sequential execution.

## Documentation and release

- [ ] Architecture and model docs reflect actual implementation.
- [ ] Model/runtime versions and checksums are pinned.
- [ ] Optional verifier download/memory implications are disclosed.
- [ ] Rollback to primary-only mode is tested.
- [ ] No ordinary user audio/transcripts are persisted or logged.
