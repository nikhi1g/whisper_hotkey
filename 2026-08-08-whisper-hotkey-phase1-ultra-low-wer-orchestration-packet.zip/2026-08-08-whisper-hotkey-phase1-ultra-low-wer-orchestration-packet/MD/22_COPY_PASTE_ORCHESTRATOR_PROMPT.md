# Copy-Paste Prompt for the Orchestrating Agent

You are the integration owner for Phase 1 of `whisper_hotkey`. Work from an explicitly recorded repository commit and compare against the latest public release baseline, `v3.6.2` at `317fced`. Read repository `SUBAGENTS.md` first.

Use sub-agents named exactly **`luna_worker`**. Give every worker an isolated worktree, a dedicated branch, exact non-overlapping `owned_paths`, and one task file from `MD/Workers/`. Workers must not merge their own branches. You own contracts, sequencing, integration, broad testing, benchmarks, rollback and the final release decision.

## Objective

Implement a Phase-1-only, three-layer local dictation pipeline that substantially reduces word error rate and produces polished punctuation/capitalization without tailoring to a particular speaker:

1. **Primary layer:** Parakeet or Whisper Turbo immediately produces a rich result with stable word IDs, timestamps, alternatives and decoder/acoustic evidence.
2. **Accuracy layer:** calibrate per-word probability of error, merge only uncertain words into bounded original-audio spans, decode those spans with a stronger or complementary local verifier, and apply only evidence-backed replacements while locking high-confidence words.
3. **Formatting layer:** predict punctuation, capitalization and sentence-boundary labels on the final word IDs. It must be lexically invariant.

The target is `WER <= 1%` only on a frozen, clean-and-recoverable application benchmark under a documented normalizer. Do not claim universal sub-1% WER. Accuracy takes priority over compute, but final results should normally land within a few seconds and decode-while-speaking must remain incrementally responsive.

## Scope

Apply the upgrade to every supported combination of:

- press-and-hold;
- toggle;
- Pause Mode;
- Decode While Speaking;
- Model Ready;
- Decode After Speaking;
- Parakeet variants;
- Whisper Turbo.

Phase 2 is prohibited: no user enrollment, voiceprint, target-speaker isolation, personal acoustic training, retained corpus, or overnight/continual training.

## Required sequence

Follow the waves in `MD/00_ORCHESTRATOR_START_HERE.md`. Begin with W00, W01, W04 and W12. Do not add a larger verifier until rich contracts, source-audio lifetime and a frozen benchmark exist. Then integrate provider evidence, calibrated confidence, uncertain-span planning, guarded candidate fusion, lexically invariant formatting, streaming sentence stability and the actor-owned coordinator.

## Non-negotiable safety and complexity rules

- The source audio remains alive until every selected pass completes or cancels.
- Only the coordinator owns the canonical transcript and paste action.
- Formatting cannot insert, delete, substitute or reorder lexical tokens.
- A verifier cannot change locked high-confidence anchors without a separately audited exception.
- Numbers, units, negations and named entities require stronger evidence, not merely linguistic plausibility.
- Candidate count, span length, total verifier duration, queues, prompts, alignment matrices and retained audio are hard-bounded.
- Serialize each model runtime unless its API explicitly guarantees concurrent inference.
- Profile ANE plus Metal overlap; never assume more threads or simultaneous GPU work is faster.
- On enhancement timeout/failure, return the guarded primary transcript.
- No cloud call, transcript logging or production audio persistence.

## Verifier experiments

Evaluate in this order, without assuming the newest or largest model wins:

1. existing complementary engine;
2. full Whisper large-v3 on bounded uncertain spans;
3. Parakeet 1.1B TDT/hybrid through a viable Apple-local runtime such as `parakeet.cpp`;
4. Qwen3-ASR 1.7B through MLX only if earlier candidates fail and deployment is stable.

Use paired benchmark evidence, repair precision, false-rewrite rate, latency, memory and model-footprint data. A model with lower standalone WER can still be a bad verifier if its errors are correlated or it corrupts correct primary words.

## Completion

Do not call the work complete until `MD/19_DEFINITION_OF_DONE.md` and `MD/15_PROMOTION_GATES_AND_ROLLOUT.md` pass. Return a final integration report containing exact SHAs, model hashes, source changes, tests, raw benchmark artifacts, paired confidence intervals, ablations, performance/soak results, known limitations and rollback proof.
