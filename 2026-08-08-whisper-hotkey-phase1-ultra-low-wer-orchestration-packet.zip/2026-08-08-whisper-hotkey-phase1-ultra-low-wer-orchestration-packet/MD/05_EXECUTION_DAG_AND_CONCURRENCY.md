# Execution DAG and Concurrency

## Correct dependency graph

```mermaid
flowchart TD
    CAP[Capture canonical audio] --> PRE[Preprocess/VAD/audio quality]
    CAP --> PRI[Primary decode]
    PRE --> PRI
    PRI --> WORDS[Stable word records]
    WORDS --> CONF[Confidence estimation]
    WORDS --> PUNC[Punctuation/boundary scoring]
    CONF --> SPANS[Uncertain span planning]
    SPANS --> VER[Selective verifier decode]
    WORDS --> FUSE[Candidate fusion]
    VER --> FUSE
    FUSE --> FORMAT[Apply lexical-invariant formatting]
    PUNC --> FORMAT
    FORMAT --> GUARD[Final guards]
    GUARD --> INSERT[Single ordered insertion]
```

## What may run concurrently

- capture and model warm-up;
- VAD/audio-quality features and primary decode preparation;
- punctuation scoring and verifier work after primary words exist;
- independent verifier spans, subject to a strict concurrency cap and model thread safety;
- benchmark-only candidate models in isolated processes.

## What must be serialized

- canonical transcript mutation;
- lock/unlock decisions;
- generation acceptance;
- source-audio deletion;
- final paste/submit;
- access to a provider runtime that is not documented as reentrant;
- model unload/reload transitions.

## Actor ownership

Use actors for mutable session state rather than broad locks:

- `RecognitionPipelineCoordinator`: canonical state and final delivery;
- one actor per in-process model runtime;
- `AudioLease`: reference-counted or session-owned file lifetime;
- `VerifierScheduler`: concurrency, deadlines, and budget;
- `MetricsSink`: benchmark-only, content-free production metrics.

## Deadlines

Suggested initial budgets, to be tuned empirically:

| Stage | Decode After Speaking / Model Ready | Decode While Speaking |
|---|---:|---:|
| Primary result | 700 ms preferred | sentence window must remain faster than real time |
| Confidence + formatting | 150 ms | 100 ms after stable words |
| Selective verifier | 1.5 s preferred, 3 s hard | 400–900 ms per finalized sentence |
| Final guards + insertion | 50 ms | 50 ms |

Do not fail the dictation merely because the verifier times out. Fall back to the guarded primary result.

## Cancellation

Every task carries session ID and generation. On cancel, model change, or new session:

1. invalidate generation;
2. cancel children;
3. stop accepting provider events;
4. release model leases according to mode;
5. delete audio only after all holders release it;
6. suppress all stale insertion.

## Metal/ANE contention

“Parallel” does not guarantee faster completion. Two GPU-heavy decodes can serialize inside Metal or evict memory. Profile these configurations separately:

- ANE primary + Metal verifier;
- Metal primary + ANE verifier;
- Metal primary + Metal verifier sequential;
- Metal primary + Metal verifier overlapped;
- CPU punctuation vs ANE punctuation.

Choose per-device policy from measured p95 latency and peak RSS, not processor-count heuristics alone.
