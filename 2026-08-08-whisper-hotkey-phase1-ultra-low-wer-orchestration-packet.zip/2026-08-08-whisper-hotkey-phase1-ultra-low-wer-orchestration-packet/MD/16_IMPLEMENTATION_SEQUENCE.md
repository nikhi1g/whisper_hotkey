# Implementation Sequence

## Milestone 0: pin and reproduce

- Record current commit/release, dependency versions, model checksums, hardware, macOS, and benchmark results.
- Add a repeatable command that produces baseline JSONL.
- Reproduce every input/processing-mode smoke path.

## Milestone 1: rich contracts and audio ownership

- Add provider-neutral rich recognition contracts.
- Upgrade helper protocol to version 2.
- Move source-audio deletion from recognizer to session coordinator/lease.
- Keep outer behavior identical through a text projection.

**Exit:** current tests pass and text output is unchanged.

## Milestone 2: provider evidence

- Whisper: timestamps, token log probabilities, fallback/beam metadata, alternatives.
- Parakeet: retain FluidAudio word/timing/provenance fields.
- Add fixture and integration tests for both.

**Exit:** rich result survives provider -> Swift -> mode accumulator.

## Milestone 3: benchmark and calibration

- Expand benchmark runner and frozen corpora.
- Implement word alignment and confidence labels.
- Establish entropy/probability/beam/disagreement baselines.
- Calibrate per engine/model/profile.

**Exit:** confidence PR-AUC and calibration report generated reproducibly.

## Milestone 4: selective verifier experiments

- Add an offline experiment harness before product integration.
- Compare full Whisper large-v3, complementary current engine, Parakeet 1.1B, and optional Qwen3-ASR.
- Measure repair oracle, actual fusion gain, latency, peak RSS, and cross-model diversity.
- Select one production verifier path per primary or decide one shared verifier.

**Exit:** measured decision document and pinned model/runtime.

## Milestone 5: span planner and fusion

- Build bounded uncertain spans from calibrated word/gap risk.
- Re-decode original audio spans.
- Add timestamp-aware DP alignment, locked anchors, and guarded candidate selection.
- Add repair decision metadata.

**Exit:** selective repair beats primary-only without high-confidence corruption.

## Milestone 6: formatting

- Add word-preserving punctuation/casing/boundary scorer.
- Add lexical invariance guard.
- Add thinking-pause and incomplete-clause tests.

**Exit:** formatting metrics improve and lexical mutation is zero.

## Milestone 7: sentence-stable streaming

- Replace string chunk joining with overlapping word/timestamp reconciliation.
- Maintain stable prefix and revisable tail.
- Separate decode boundary, punctuation boundary, and paste boundary.
- Integrate whole-sentence commits for Pause Mode.

**Exit:** no boundary duplicates/drops and all mode combinations pass.

## Milestone 8: coordinator and performance

- Wire staged DAG behind one actor-owned final commit.
- Add deadlines, backpressure, cancellation, model residency, and heterogeneous compute policy.
- Profile M5 Pro and at least one lower-memory Apple Silicon Mac.

## Milestone 9: release validation

- Run frozen benchmarks, ablations, soak tests, Instruments traces, and rollback drill.
- Update docs and model-size/memory disclosures.
- Ship only after promotion gates.
