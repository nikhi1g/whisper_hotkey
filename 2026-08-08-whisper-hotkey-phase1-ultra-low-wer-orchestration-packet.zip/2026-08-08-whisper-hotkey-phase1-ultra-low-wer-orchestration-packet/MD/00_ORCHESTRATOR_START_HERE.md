# Orchestrator Start Here

## Role

You are the sole integration owner. Delegate implementation and focused investigation to sub-agents named **`luna_worker`**. Use isolated worktrees and non-overlapping `owned_paths`, following the repository's existing `SUBAGENTS.md` contract.

## Mission

Implement Phase 1 of the ultra-low-error dictation pipeline in `whisper_hotkey`:

- Preserve rich recognition evidence from both Parakeet and Whisper.
- Add calibrated word-level uncertainty.
- Selectively re-decode only uncertain original-audio spans with a stronger or complementary verifier.
- Fuse candidates deterministically and protect high-confidence words.
- Add lexically invariant punctuation, capitalization, and sentence-boundary restoration.
- Apply the architecture to every input and processing-mode combination.
- Demonstrate accuracy gains through a frozen benchmark suite without unacceptable latency, memory, energy, or reliability regressions.

## Explicitly out of scope

Do not implement:

- user voice enrollment;
- target-speaker identification or extraction;
- personal acoustic adapters;
- user-specific continual training;
- overnight training;
- persistent recording history;
- cloud transcription;
- unrestricted LLM transcript rewriting.

## Non-negotiable repository facts

Before delegating, verify these facts against the current checkout:

1. `WhisperRecognition.swift` returns `String` from public decode APIs.
2. `WhisperHelperProtocol.EventEnvelope` keeps only `event`, `text`, `code`, and `message`.
3. The Whisper command-line fallback uses `-nt`, so timestamps are disabled.
4. `WhisperRecognizer.transcribe` deletes its `WhisperAudioFile` in a `defer`.
5. `ParakeetRuntime` collapses the FluidAudio result to `.text`.
6. `BackgroundPredecode` accumulates `[String]` and joins chunks with spaces.
7. The C++ helper computes aggregate log-probability/weak-token/no-speech/repetition fields, but Swift discards them.

If any fact changed after this packet date, update the audit and task dependencies before coding.

## Worktree assignments

Create one worktree and branch per worker. The suggested dependency order is:

| Wave | Worker packet | May start when |
|---|---|---|
| 0 | `W00_BASELINE_AND_REPRODUCTION.md` | Immediately |
| 1 | `W01_RICH_RESULT_CONTRACT.md` | Immediately |
| 1 | `W04_AUDIO_SESSION_OWNERSHIP.md` | Immediately |
| 1 | `W12_BENCHMARK_AND_METRICS.md` | Immediately |
| 2 | `W02_WHISPER_EVIDENCE.md` | W01 contract shape accepted |
| 2 | `W03_PARAKEET_EVIDENCE.md` | W01 contract shape accepted |
| 2 | `W09_LEXICALLY_INVARIANT_FORMATTING.md` | W01 stable word IDs accepted |
| 2 | `W13_PERFORMANCE_MEMORY_RELIABILITY.md` | W00 baseline available |
| 3 | `W05_CONFIDENCE_CALIBRATION.md` | W02 and W03 evidence fixtures available |
| 3 | `W06_VERIFIER_MODEL_EXPERIMENTS.md` | W00 corpus runner available |
| 3 | `W10_STREAMING_SENTENCE_STABILITY.md` | W01 and W04 accepted |
| 4 | `W07_UNCERTAIN_SPAN_PLANNER.md` | W05 confidence contract accepted |
| 4 | `W08_CANDIDATE_FUSION_AND_SAFETY.md` | W02/W03 output fixtures available |
| 5 | `W11_PIPELINE_COORDINATOR.md` | W04, W05, W07, W08, W09 interfaces accepted |
| 6 | `W14_INTEGRATION_AND_RELEASE_REVIEW.md` | All implementation branches ready |

## Integration policy

- Do not let workers merge directly into the integration branch.
- Require each worker to return: commit SHA, files changed, tests run, benchmark delta, risks, and unresolved assumptions.
- Integrate contracts first, providers second, deterministic transforms third, coordinator fourth, mode integration fifth.
- Run broad tests only after related branches are batched.
- Reject any branch that silently changes selected recognition engine, sends audio over the network, persists transcript/audio content, or introduces unbounded queues.

## Required architecture

```mermaid
flowchart LR
    A[Canonical session audio] --> P[Primary recognizer]
    P --> R[Rich word result]
    R --> C[Confidence estimator]
    R --> F[Punctuation and boundary scorer]
    C --> S[Uncertain span planner]
    S --> V[Selective verifier on original audio spans]
    V --> U[Candidate fusion and guarded repair]
    R --> U
    U --> L[Lexically invariant formatting]
    F --> L
    L --> G[Final guards]
    G --> I[Single ordered insertion]
```

The coordinator owns the canonical transcript. No layer writes directly into the focused application.

## Promotion rule

A candidate implementation may ship only when all of these hold:

- statistically supported WER improvement on the frozen app corpus;
- no material regression on public corpora;
- high-confidence word corruption below the configured hard ceiling;
- repair precision above the configured floor;
- punctuation and boundary scores improve without lexical mutation;
- p95 completion latency remains within the mode budget;
- peak RSS and temporary storage stay bounded;
- rapid cancel/restart and all mode combinations pass race and cleanup tests.

Read `MD/15_PROMOTION_GATES_AND_ROLLOUT.md` for exact gates. Also read `MD/21_LATEST_RELEASE_VS_MAIN.md` before choosing the integration base.
