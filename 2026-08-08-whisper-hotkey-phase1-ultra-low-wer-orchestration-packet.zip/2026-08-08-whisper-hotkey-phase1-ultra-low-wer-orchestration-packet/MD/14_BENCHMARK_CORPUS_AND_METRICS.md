# Benchmark Corpus and Metrics

## Principle

A sub-1% result on a tiny clean-read subset is not proof of a seamless dictation product. Maintain several frozen tracks and report each independently.

## Track A: repository smoke benchmark

Keep the current 100-utterance LibriSpeech subset to catch obvious regressions and compare with historical numbers. Do not use it as the release claim.

## Track B: full public accuracy

At minimum:

- LibriSpeech test-clean and test-other;
- Earnings-22 for long-form, accented, real-world speech;
- Contextual Earnings-22 for rare/custom vocabulary;
- TED-LIUM 3 or GigaSpeech evaluation for spontaneous/presentation speech, subject to license and storage constraints;
- AMI single-distant-microphone or headset subsets for conversational/far-field behavior;
- controlled MUSAN mixtures for music, speech, and noise robustness.

## Track C: frozen application dictation corpus

Create a consented, non-personalized evaluation set representing the product:

- hotkey-length utterances;
- technical terms, names, acronyms, paths, numbers, dates, and units;
- thinking pauses and self-restarts;
- questions and compound sentences;
- quiet, fan, keyboard, music, TV, café, and distant-speech conditions;
- several microphones and device distances;
- multiple accents/speaking rates;
- sentence and chunk boundary stress cases.

Keep train/calibration/dev/test partitions speaker- and session-disjoint. Phase 1 may calibrate confidence, but may not fine-tune to individual users.

## Scoring profiles

Report both:

- **normalized WER:** lowercased/standardized punctuation-independent lexical accuracy;
- **display WER/CER:** case and formatting-sensitive where appropriate.

Freeze normalization scripts and include their version hash in every report.

## Required metrics

### Lexical

- WER with substitutions/deletions/insertions;
- CER;
- homophone exact match;
- number/date/unit exact match;
- named-entity/proper-noun accuracy;
- hallucination/repetition rate.

### Confidence/repair

- incorrect-word PR-AUC;
- ECE, MCE, NCE;
- error recall at verifier budget;
- repair precision and recall;
- false rewrite rate;
- high-confidence corruption rate;
- verifier audio ratio and invocation rate.

### Formatting

- punctuation F1 by mark and macro average;
- sentence-boundary F1;
- false-period rate at thinking pauses;
- capitalization error rate;
- proper-noun casing accuracy;
- lexical mutation count.

### Systems

- time to first primary result;
- time to stable sentence;
- final completion p50/p95/p99;
- real-time factor;
- peak RSS;
- CPU/GPU/ANE utilization where measurable;
- energy/thermal state;
- cancellation and rapid-restart failure rate.

## Statistics

- paired bootstrap confidence intervals for WER deltas;
- paired per-utterance comparisons;
- report absolute and relative change;
- include regression counts, not only averages;
- require ablations: primary only, +confidence, +verifier, +fusion, +formatting.

## Benchmark integrity

- no tuning on test labels;
- no dropping difficult files after seeing results;
- no model-specific normalization advantages;
- record model file checksum, runtime version, commit SHA, macOS version, hardware, thermal state, and mode;
- persist only consented benchmark audio, not ordinary user dictation.
