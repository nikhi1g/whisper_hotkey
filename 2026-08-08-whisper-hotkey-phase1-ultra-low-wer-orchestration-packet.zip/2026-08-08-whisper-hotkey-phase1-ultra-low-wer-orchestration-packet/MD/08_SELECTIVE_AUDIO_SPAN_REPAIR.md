# Selective Original-Audio Span Repair

## Purpose

Spend expensive verifier compute only where the primary result is plausibly wrong. The verifier must hear the original audio, not merely receive the primary text.

## Span construction

1. Mark words whose calibrated error probability exceeds the provider-specific threshold.
2. Add adjacent deletion-risk gaps and truncated boundary regions.
3. Merge marked words separated by less than a configurable gap.
4. Add acoustic padding, initially 250-500 ms on each side.
5. Extend to a nearby VAD or word boundary when it prevents a clipped phoneme.
6. Attach bounded left/right text context, but keep the audio span authoritative.
7. Cap span duration and total verifier coverage.

## Suggested initial bounds

These are experiment defaults, not constants:

- minimum repair span: 0.8 s;
- normal maximum repair span: 8 s;
- catastrophic fallback span: complete sentence, not complete session;
- maximum merged gap: 350 ms;
- left/right padding: 350 ms;
- maximum verifier coverage: 25% of session audio in normal mode;
- maximum concurrent verifier spans: 1 per model runtime, 2 only after profiling.

## Boundary context

The verifier should return text and timing for the padded span. Fusion must trim padding by aligning to locked anchor words or timestamps. Never paste the padded transcript directly.

## Catastrophic evidence

Permit a sentence-level re-decode when any of these occurs:

- primary output is empty despite strong speech evidence;
- severe repetition/hallucination;
- alignment is impossible;
- most words in a sentence are uncertain;
- a chunk boundary is demonstrably truncated;
- timestamp monotonicity is invalid.

A whole-session re-decode is a last-resort finalization path for short dictations, not the default accuracy layer.

## Deletion recovery

Word confidence alone cannot detect a word the primary omitted. Add gap-level features:

- unusually long acoustic activity between adjacent word timestamps;
- verifier word inserted between two aligned anchors;
- cross-engine insertion agreement;
- VAD speech region with no corresponding word;
- truncated boundary signal.

## Test cases

- one uncertain homophone in a clean sentence;
- two adjacent uncertain words;
- uncertain word at audio start/end;
- omitted short function word;
- clipped chunk boundary;
- number and unit phrase;
- long pause inside a clause;
- repeated phrase hallucination;
- no uncertainty, verifier must not run;
- uncertainty budget exceeded, degrade deterministically.
