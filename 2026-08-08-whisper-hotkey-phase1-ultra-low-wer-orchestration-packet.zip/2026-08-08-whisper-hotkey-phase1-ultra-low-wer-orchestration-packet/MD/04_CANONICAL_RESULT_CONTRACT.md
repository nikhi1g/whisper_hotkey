# Canonical Recognition Result Contract

## Purpose

Replace every public `String` recognition boundary with one provider-neutral result. Keep a compatibility `text` projection only at the outermost delivery edge during migration.

## Proposed conceptual types

```swift
struct RecognitionResult: Sendable, Codable {
    let sessionID: UUID
    let generation: UInt64
    let engine: RecognitionEngineID
    let model: ModelIdentity
    let words: [RecognizedWord]
    let segments: [RecognizedSegment]
    let alternatives: [RecognitionAlternative]
    let utteranceEvidence: UtteranceEvidence
    let timing: RecognitionTiming
    let completeness: DecodeCompleteness
}

struct RecognizedWord: Sendable, Codable, Identifiable {
    let id: StableWordID
    var text: String
    let startTime: Duration
    let endTime: Duration
    let tokenRange: Range<Int>?
    let rawEvidence: WordEvidence
    var calibratedErrorProbability: Double?
    var lockState: WordLockState
    var provenance: WordProvenance
}
```

The exact Swift names may change, but the information must survive end to end.

## Stable word identity

`StableWordID` must be deterministic within a session and independent of formatting. Suggested composition:

```text
session UUID + provider decode ID + monotonic provider word index
```

When fusion replaces a word, preserve a provenance edge from old IDs to new IDs rather than silently reusing an unrelated ID.

## Required evidence fields

### Whisper

- token IDs and token log probabilities;
- token and word timestamps;
- beam/candidate scores and rank where exposed;
- no-speech probability;
- temperature/fallback path;
- repetition/compression/hallucination indicators;
- decoding strategy, beam size, prompt use, model/quantization identity.

### Parakeet

Preserve whatever the pinned FluidAudio API exposes for the selected checkpoint:

- word/token timings;
- decoder score/posterior information where available;
- streaming/offline mode;
- chunk and seam provenance;
- custom vocabulary/boosting state;
- model version and compute units.

Do not fabricate confidence from missing fields. Mark evidence availability explicitly.

## Completeness states

- `provisional`: revisable streaming tail;
- `stablePrefix`: not expected to change under normal continuation;
- `completeSentence`: semantic/acoustic endpoint accepted;
- `finalSession`: end-of-dictation result;
- `truncated`: boundary likely cut a word or clause;
- `failed`: provider result invalid.

## Serialization

The C++ helper protocol should use versioned JSON lines:

```json
{
  "protocol_version": 2,
  "event": "result",
  "request_id": "...",
  "result": {
    "text": "...",
    "words": [],
    "segments": [],
    "alternatives": [],
    "utterance_evidence": {},
    "timing": {}
  }
}
```

- Reject unsupported major versions.
- Tolerate missing optional evidence from older helpers.
- Add fixture tests for malformed, partial, and oversized messages.
- Cap array sizes and line length before decoding to prevent memory abuse.

## Migration rule

1. Introduce rich contracts and adapters.
2. Preserve current text behavior through `result.renderedText`.
3. Convert providers one at a time.
4. Convert accumulators/coordinators.
5. Remove string-only APIs after mode tests pass.
