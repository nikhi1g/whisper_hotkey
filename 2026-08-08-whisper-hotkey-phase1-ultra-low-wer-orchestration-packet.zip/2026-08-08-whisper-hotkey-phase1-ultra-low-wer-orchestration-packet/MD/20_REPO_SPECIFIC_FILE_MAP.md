# Repository-Specific File Map

This map is guidance, not permission for multiple workers to edit the same path. The orchestrator must resolve exact ownership before spawning worktrees.

| Current path | Current role/problem | Expected Phase 1 direction |
|---|---|---|
| `Sources/WhisperHotkeyCore/Contracts.swift` | no rich recognition result | add provider-neutral contracts or a new focused contract file in Core |
| `Sources/WhisperHotkeyASR/WhisperRecognition.swift` | String APIs; helper parser drops evidence; fallback disables timestamps; recognizer deletes audio | rich result APIs, protocol v2, timestamp-capable fallback, caller-owned audio |
| `Sources/WhisperModelHelper/main.cpp` | aggregate confidence and full-utterance greedy->beam fallback | emit token/word timing, evidence, alternatives, strategy metadata; retain compatibility |
| `Sources/WhisperHotkeyASR/ParakeetRuntime.swift` | returns result text only | preserve FluidAudio 0.15.5 rich result/timing/provenance |
| `Sources/WhisperHotkeyCore/BackgroundPredecode.swift` | accumulates strings | accumulate/reconcile timed word results with stable prefix/revisable tail |
| recorder/session audio files under ASR/Core | current temporary ownership optimized for one consumer | add session-owned audio lease and bounded span views |
| App orchestrator under `WhisperHotkeyApp` | serial state/delivery | host one pipeline coordinator and final commit only |
| existing model/preferences types | primary model selection | add optional accuracy/verifier policy without invalid pairings |
| `docs/ARCHITECTURE.md` | documents serial String pipeline | update only after code lands |
| `docs/MODELS.md` | 100-utterance benchmark and current model table | add verifier footprint and expanded benchmark results |
| ASR/Core/App test targets | current behavior tests | add rich protocol, alignment, cancellation, mode, and performance fixtures |
| benchmark scripts/data manifests | small LibriSpeech smoke set | preserve smoke set; add frozen public/application tracks |

## Suggested new focused files

Names are illustrative:

```text
Sources/WhisperHotkeyCore/RecognitionResult.swift
Sources/WhisperHotkeyCore/WordAlignment.swift
Sources/WhisperHotkeyASR/AudioLease.swift
Sources/WhisperHotkeyASR/ConfidenceEstimator.swift
Sources/WhisperHotkeyASR/UncertainSpanPlanner.swift
Sources/WhisperHotkeyASR/VerifierScheduler.swift
Sources/WhisperHotkeyASR/CandidateFusion.swift
Sources/WhisperHotkeyASR/PunctuationFormatter.swift
Sources/WhisperHotkeyApp/RecognitionPipelineCoordinator.swift
```

Prefer small cohesive files to turning `WhisperRecognition.swift` into a larger monolith.

## Path-conflict warning

Workers W01, W02, and W03 will all depend on recognition contracts, but only W01 should own the canonical contract paths. Provider workers adapt to the accepted contract in their own provider paths. W11 integrates; it must not redesign contracts late without sending changes back through review.
