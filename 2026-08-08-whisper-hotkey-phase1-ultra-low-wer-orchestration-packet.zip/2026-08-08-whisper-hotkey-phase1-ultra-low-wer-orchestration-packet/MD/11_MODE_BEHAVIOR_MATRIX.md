# Mode Behavior Matrix

The architecture must apply to every activation and processing combination. Activation controls capture; processing controls when recognition occurs.

| Activation behavior | Processing behavior | Required accuracy behavior |
|---|---|---|
| Press and Hold | Decode After Speaking | Full-session primary, selective repair, final formatting, one insertion on release |
| Press and Hold | Model Ready | Same output contract with resident primary and optional verifier policy |
| Press and Hold | Decode While Speaking | Sentence-window predecode while held; final tail and guarded reconciliation on release |
| Toggle | Decode After Speaking | Same as Press and Hold but explicit second press ends capture |
| Toggle | Model Ready | Resident models, one final insertion |
| Toggle | Decode While Speaking | Stable sentence processing during capture, one final insertion unless Pause Mode behavior is selected |
| Pause Mode | Decode After Speaking | Pause detection may mark boundaries, but no lexical finalization until stop if configured as deferred |
| Pause Mode | Model Ready | Resident model and semantic endpointing; whole sentences may commit according to existing Pause Mode UX |
| Pause Mode | Decode While Speaking | Whole-sentence units only; stable prefix plus revisable tail; ordered commits |

## Shared rules

- Canonical full-session audio always exists until the session pipeline finishes.
- Background chunks are views/snapshots, not independent sources of truth.
- Overlap is required around sentence windows.
- Chunk output must be reconciled by word IDs/timestamps, not joined with spaces.
- A final tail decode is mandatory.
- A complete-session fallback may run if background processing fails.
- Only the coordinator may paste.

## Decode While Speaking

The user asked for whole sentences, not word-by-word display. Use:

- sentence-scale windows;
- natural pause/end-of-utterance evidence;
- truncation detection;
- stable-prefix detection;
- bounded future context;
- provisional tail that can be revised before insertion.

The time-complexity advantage comes from processing audio during capture and only revisiting overlap/uncertain spans, not from prematurely committing incomplete text.

## Pause Mode distinction

Pause Mode controls when text is committed. Decode While Speaking controls when audio is decoded. They are orthogonal. Do not conflate a recognition boundary with a punctuation boundary or a paste boundary.
