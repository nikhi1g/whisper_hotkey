# Word Confidence and Calibration

## Objective

Estimate the probability that each recognized word is wrong. Raw decoder probability is not a calibrated probability of correctness and must not be used as a universal threshold.

## Feature tiers

### Tier A: zero-training features

- minimum, mean, and geometric mean token probability;
- Shannon/Tsallis/Rényi entropy when distributions are available;
- token duration and blank dominance;
- no-speech probability;
- compression/repetition/hallucination flags;
- position near a chunk boundary;
- N-best word disagreement;
- primary/verifier disagreement after alignment.

### Tier B: calibrated scalar model

Fit temperature scaling, Platt/logistic calibration, or isotonic regression on a held-out calibration split. Inputs must be produced without using the test split.

### Tier C: learned confidence estimator

Only after Tier A/B baselines are measured, test a lightweight sequence estimator using:

- beam score/rank features;
- lexical neighborhood;
- provider identity;
- acoustic quality features;
- word aggregation.

Keep it small, deterministic at inference, and independently versioned.

## Labels

Align hypothesis words to ground-truth words using a reproducible edit path. Label substitutions and insertions as incorrect. Deletion risk requires boundary/gap features because no hypothesis word exists to label.

## Metrics

Do not optimize only accuracy on a highly imbalanced correct/incorrect label set. Report:

- PR-AUC for incorrect-word detection;
- ROC-AUC as secondary;
- expected calibration error (ECE);
- maximum calibration error (MCE);
- normalized cross entropy (NCE);
- false-unlock rate among correct high-confidence words;
- recall of actual errors at the chosen verifier budget;
- verifier-audio ratio.

## Operating point

Select thresholds on validation data using a constrained objective:

```text
maximize expected corrected errors
subject to:
  high-confidence corruption <= hard ceiling
  verifier audio ratio <= budget
  p95 latency <= mode budget
```

Do not use a single threshold across providers unless calibration proves it valid.

## Confidence composition

An initial logistic formulation may be used for experiments:

```text
logit P(error_i) = b_provider
                 + w1 * calibrated_entropy_i
                 + w2 * nbest_disagreement_i
                 + w3 * boundary_proximity_i
                 + w4 * acoustic_degradation_i
                 + w5 * repetition_risk_i
                 + w6 * context_inconsistency_i
```

This is a baseline, not a mandated final model.

## Safety

- Treat missing evidence as unknown, not high confidence.
- Never unlock an entire sentence because one word is uncertain.
- Expand spans only enough to recover coarticulation and context.
- Keep numbers, units, negation, and proper nouns under stricter thresholds.
- Version calibration by engine, model, quantization, decode profile, and major runtime version.
