# Latest Release Versus Current Main

**Latest public release seen on 2026-08-08:** `v3.6.2` at `317fced`  
**Implementation audit target:** current GitHub `main`

## Orchestrator rule

Before spawning workers, choose and record the integration base. Prefer current `main` for new development unless the repository owner directs otherwise, but preserve a reproducible `v3.6.2` benchmark as the shipped-user baseline.

Do not combine these into one number:

- released `v3.6.2` accuracy and latency;
- pre-change current-`main` accuracy and latency;
- candidate branch accuracy and latency.

If current `main` already contains model, preset, segmentation, or benchmark changes beyond `v3.6.2`, quantify them before attributing gains to the three-layer architecture.

## Required baseline table

| Build | Commit | Engine/model | Processing mode | WER | p50/p95 completion | Peak RSS |
|---|---|---|---|---:|---:|---:|
| Release | `317fced` | | | | | |
| Current main | record locally | | | | | |
| Candidate | record locally | | | | | |
