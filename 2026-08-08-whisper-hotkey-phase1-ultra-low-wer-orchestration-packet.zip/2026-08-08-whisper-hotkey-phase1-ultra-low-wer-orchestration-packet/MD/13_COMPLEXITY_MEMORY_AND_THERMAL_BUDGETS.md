# Complexity, Memory, and Thermal Budgets

## Core objective

Use more compute when it materially lowers error, but keep compute proportional to uncertainty and prevent pathological memory/time growth.

## Complexity controls

- primary decode once per canonical sentence/session path;
- confidence and formatting linear in words;
- verifier proportional to uncertain duration `U`, not total duration `T`;
- align only bounded spans;
- cap N-best candidates;
- cap overlap and prompt context;
- cap queued sentence windows;
- coalesce adjacent uncertain spans;
- use backpressure instead of unbounded task creation.

## Initial hard caps to benchmark

| Resource | Initial cap |
|---|---:|
| N-best candidates per provider/span | 8 |
| Candidate words per repair span | 96 |
| Dynamic-programming alignment cells | 20,000 |
| Normal verifier span | 8 s |
| Total verifier audio ratio | 25% |
| Pending decode windows | 2 |
| Concurrent calls per model runtime | 1 |
| In-memory rendered alternatives | 16 per session |
| Text prompt/context | existing bounded policy or measured equivalent |

## Memory

Track:

- resident model memory by configuration;
- peak RSS during primary + verifier overlap;
- Metal allocation and model cache behavior;
- canonical audio growth for maximum recording duration;
- temporary span files;
- per-session word/candidate graph size;
- retained tasks/closures after cancellation.

Use Instruments Leaks, Allocations, Time Profiler, Metal System Trace, and `xctrace` where practical.

## Thermal policy

Accuracy remains primary, but sustained thermal pressure can make latency worse. Define deterministic fallback order:

1. keep primary quality;
2. reduce verifier concurrency;
3. reduce verifier coverage to highest-risk spans;
4. defer low-value formatting refinement;
5. never lower accuracy silently by changing the selected primary model.

## Threading

- Keep Swift structured concurrency at the orchestration level.
- Let model runtimes manage internal CPU/Metal/ANE parallelism.
- Avoid nested oversubscription from multiple `Task.detached` calls plus maximum model thread counts.
- Benchmark thread counts on M5 Pro and lower-end Macs.
- Use actors or immutable messages; avoid broad locks around inference.
