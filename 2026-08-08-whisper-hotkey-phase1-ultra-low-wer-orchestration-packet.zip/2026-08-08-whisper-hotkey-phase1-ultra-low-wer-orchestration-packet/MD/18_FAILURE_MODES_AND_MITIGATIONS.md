# Failure Modes and Mitigations

| Failure | Cause | Mitigation |
|---|---|---|
| Correct word rewritten | over-aggressive context/LLM | locked anchors, calibrated threshold, audio-only candidates |
| Missing word never flagged | word-only confidence | gap risk, VAD-without-word, cross-model insertion evidence |
| Duplicate boundary text | independent chunk strings | overlapping timed words, DP reconciliation, stable IDs |
| Dropped boundary word | truncated window | overlap, truncation detector, final tail, sentence fallback |
| Period after thinking pause | pause-only endpoint | semantic completeness + prosody + bounded lookahead |
| Verifier makes latency worse | excessive span coverage/model contention | calibrated budget, coalescing, heterogeneous compute, timeout |
| Peak memory explosion | two resident large models/N-best retention | residency policy, bounded candidates, sequential Metal, memory pressure fallback |
| Use-after-delete | recognizer-owned audio cleanup | session `AudioLease` |
| Stale paste | late child task | generation gating and coordinator-only delivery |
| Deadlock | mixed locks/process/model lifecycle | actor ownership, structured cancellation, lock-order elimination |
| Model runtime race | concurrent calls to non-reentrant runtime | one actor/semaphore per runtime |
| Confidence looks good but is wrong in noise | overconfidence/domain shift | per-condition calibration, noise track, SR-CEM/entropy features |
| Punctuation layer changes words | free-form generation | label-only output + lexical invariance proof |
| Benchmark reaches <1% through normalization | scoring leakage | frozen dual scoring, raw examples, audit normalization |
| Same-family verifier adds little | correlated errors | measure error overlap; use cross-family verifier |
| Cross-family verifier disagrees too often | timing/tokenization mismatch | timestamp-aware alignment and minimum decision margin |
| Context biases wrong proper noun | keyword overboost | candidate-only context, false-boost benchmark, bounded weights |
| Helper protocol memory abuse | oversized JSON arrays/lines | explicit caps and protocol validation |
| Enhancement failure loses transcript | pipeline coupled too tightly | primary result is always safe fallback |
