# Punctuation, Capitalization, and Sentence Boundaries

## Architecture

Use a non-autoregressive, word-preserving tagger or scorer. The input lexical word sequence is immutable. Predict:

- punctuation after each word;
- casing class for each existing word/token;
- sentence-boundary confidence;
- optional paragraph boundary only at final session scope.

## Why not free-form generation

A generative language model can silently replace homophones, numbers, names, or meaning while “cleaning” text. Lexical correction belongs in the audio-grounded accuracy layer. Formatting must operate on labels.

## Inputs

- word sequence and stable IDs;
- bounded left/right lexical context;
- pause durations;
- pitch and energy continuation features when inexpensive;
- provider punctuation prior;
- end-of-utterance/finality state;
- truncation risk;
- syntactic/semantic completeness score.

## Thinking pauses

A pause is evidence, not a decision. Do not emit a period when:

- the clause ends in a determiner, conjunction, preposition, auxiliary, or otherwise incomplete construction;
- pitch/energy suggests continuation;
- the next stable words complete the same clause;
- the pause is below a user/session-adaptive long-pause threshold;
- the chunk is marked truncated or provisional.

At final stop, punctuation may resolve with no future lookahead, but should remain conservative.

## Streaming lookahead

Use bounded lookahead measured in words/subwords rather than waiting for the complete session. A weighted lookahead scorer can compare punctuation labels against a no-punctuation baseline while preserving input words.

## Lexical invariance proof

Before accepting formatted text:

1. tokenize canonical words with a stable normalizer;
2. strip formatting/case from the candidate;
3. compare ordered lexical tokens and stable IDs;
4. reject formatting if there is any insertion, deletion, substitution, or reorder.

## Metrics

- punctuation macro/micro F1 by mark;
- sentence-boundary precision/recall/F1;
- capitalization error rate;
- proper-noun casing accuracy;
- false period rate after thinking pauses;
- lexical mutation count, hard requirement = zero;
- incremental revision rate and commit latency.

## Output policy by mode

- Decode After Speaking: format after lexical fusion, complete-session context allowed.
- Model Ready: same result, lower cold latency.
- Decode While Speaking: format stable whole-sentence units with bounded lookahead; retain a revisable tail.
- Pause Mode: a pause may trigger inference, but commit only when semantic/acoustic endpoint confidence is sufficient or the user explicitly stops.
