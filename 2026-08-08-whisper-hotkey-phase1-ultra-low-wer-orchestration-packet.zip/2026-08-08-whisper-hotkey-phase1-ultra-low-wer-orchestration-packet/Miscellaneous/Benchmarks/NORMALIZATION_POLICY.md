# WER and Display-Quality Normalization Policy

Freeze this policy before evaluating candidate outputs. Changing normalization after seeing results invalidates the comparison.

## Report at least two WERs

### Normalized lexical WER

Use a versioned English normalizer with documented handling for:

- Unicode normalization;
- casing;
- punctuation removal;
- apostrophes and contractions;
- written versus spoken numbers;
- symbols, currency and units;
- filler/disfluency policy;
- partial words and unintelligible spans.

This metric measures lexical recognition independently of display formatting.

### Display WER

Use the intended application text form, including capitalization, written-number policy and approved punctuation normalization. This catches systems that look polished but alter content.

## Separate display metrics

Do not force punctuation and capitalization into one opaque WER. Also report:

- punctuation macro/micro F1 by mark;
- sentence-boundary precision/recall/F1;
- capitalization error rate;
- proper-noun exact match;
- number/unit exact match;
- false period rate after thinking pauses;
- lexical mutation count introduced by formatting.

## Homophones

WER cannot distinguish acoustically identical spellings using audio alone. Score contextual homophone cases separately and require that any language-context choice remain inside the candidate set supported by the recognizer/verifier. Never count an unconstrained text rewrite as an acoustic improvement.
