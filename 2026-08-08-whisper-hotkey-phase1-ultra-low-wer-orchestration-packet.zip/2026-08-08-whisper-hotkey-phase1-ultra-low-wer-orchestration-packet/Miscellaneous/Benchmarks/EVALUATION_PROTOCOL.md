# Evaluation Protocol

## Claim boundary

`WER <= 1%` is a promotion target for a frozen, clean-and-recoverable application corpus under a documented normalizer. It is not a universal guarantee for arbitrary noise, overlap, accents, clipping or unheard proper nouns.

## Required comparisons

1. Current release baseline.
2. Rich-result primary decode with no repairs.
3. Confidence layer only.
4. Selective verifier only.
5. Punctuation layer only.
6. Full three-layer pipeline.
7. Ablations for each confidence feature and each verifier model.

## Statistical method

Use paired utterance-level bootstrap confidence intervals. Promote only when the candidate WER delta is below zero with the configured confidence level and safety metrics pass. Report both micro/corpus WER and macro-by-subset values.

## Safety metrics

The key metric is not only corrected errors. Track:

- repair precision;
- false rewrite rate;
- high-confidence word corruption rate;
- number/name corruption;
- lexical mutation by formatting;
- unresolved uncertainty and deadline fallback frequency.

## Timing

Measure from stop/endpoint to paste for final modes and from sentence endpoint to sentence availability for decode-while-speaking. Separate cold model load from warm steady-state inference.
