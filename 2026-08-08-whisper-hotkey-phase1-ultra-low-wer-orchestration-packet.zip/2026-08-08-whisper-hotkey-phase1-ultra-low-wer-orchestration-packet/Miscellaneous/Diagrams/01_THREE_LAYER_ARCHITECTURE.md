# Three-Layer Architecture

```mermaid
flowchart LR
    A[Canonical session audio] --> P[Primary recognizer]
    P --> R[Rich result: words, timings, alternatives, evidence]
    R --> C[Accuracy layer: calibrated word error probability]
    R --> B[Punctuation and boundary layer]
    C --> S[Merge uncertain words into bounded audio spans]
    S --> V[Stronger or complementary verifier]
    V --> F[Timestamp-aware candidate fusion]
    R --> F
    F --> G[High-confidence lexical guards]
    B --> H[Word-preserving punctuation/case labels]
    G --> H
    H --> Q[Final validation]
    Q --> I[Single ordered insertion]
```

The layers are conceptually parallel but not causally independent. The verifier needs the primary word timings and uncertainty map. Once the rich result exists, formatting evidence and verifier work may overlap. No worker or model writes directly to the focused application.
