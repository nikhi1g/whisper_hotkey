# Decode-While-Speaking State Machine

```mermaid
stateDiagram-v2
    [*] --> Capturing
    Capturing --> ProvisionalDecode: enough new audio
    ProvisionalDecode --> RevisableTail: words plus timings
    RevisableTail --> Capturing: boundary incomplete
    RevisableTail --> CandidateSentence: stable prefix + endpoint evidence
    CandidateSentence --> VerifyTail: uncertainty above threshold
    CandidateSentence --> CommitSentence: sufficiently stable
    VerifyTail --> CommitSentence: guarded repair complete or deadline reached
    CommitSentence --> Capturing: continue session
    Capturing --> FinalDrain: user stops
    FinalDrain --> CommitSentence: final complete sentence
    FinalDrain --> CommitTail: fragment fallback
    CommitTail --> [*]
    CommitSentence --> [*]: session finished
```

Committed words are immutable. Only a bounded revisable tail can change. Pause duration is evidence, not an automatic period.
