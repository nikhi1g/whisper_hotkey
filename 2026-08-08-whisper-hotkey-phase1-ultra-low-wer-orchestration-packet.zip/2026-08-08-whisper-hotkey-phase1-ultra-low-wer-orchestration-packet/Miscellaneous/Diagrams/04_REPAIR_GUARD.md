# Selective Repair Guard

```mermaid
flowchart TD
    U[Uncertain primary words] --> X[Expand by timing context]
    X --> D[Verifier decodes original audio span]
    D --> A[Align primary and verifier candidates]
    A --> K{Candidate supported by audio and confidence?}
    K -->|No| KEEP[Keep primary]
    K -->|Yes| N{Touches locked high-confidence anchor, number, or named entity?}
    N -->|Yes| KEEP
    N -->|No| R[Apply bounded replacement]
    R --> V[Re-run local alignment and invariants]
    V -->|Pass| OUT[Accept repair]
    V -->|Fail| KEEP
```
