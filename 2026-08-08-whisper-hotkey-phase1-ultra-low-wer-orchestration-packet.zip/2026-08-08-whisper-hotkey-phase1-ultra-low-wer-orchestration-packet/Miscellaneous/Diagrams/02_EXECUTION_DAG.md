# Execution DAG

```mermaid
flowchart TD
    CAP[Capture 16 kHz mono session audio] --> PRE[Bounded preprocessing and VAD]
    PRE --> PRI[Primary decode]
    PRI --> WORDS[Stable word graph]
    WORDS --> CONF[Confidence calibration]
    WORDS --> PUNC[Punctuation/boundary scoring]
    CONF --> PLAN[Uncertain span planner]
    PLAN -->|No uncertain span| MERGE[Canonical merge]
    PLAN -->|Bounded spans| VER[Verifier decode]
    VER --> MERGE
    WORDS --> MERGE
    MERGE --> FORMAT[Apply label-only formatting]
    PUNC --> FORMAT
    FORMAT --> SAFE[Lexical, numeric, ordering and generation guards]
    SAFE --> PASTE[One ordered paste]
```

## Concurrency rule

- Preload models and prepare reusable buffers before capture ends.
- After primary decode, run punctuation scoring and selective verifier tasks concurrently where compute resources do not contend destructively.
- Serialize each individual model runtime behind an actor/queue unless its API documents safe concurrent inference.
- Benchmark ANE plus Metal overlap; do not assume it is faster.
