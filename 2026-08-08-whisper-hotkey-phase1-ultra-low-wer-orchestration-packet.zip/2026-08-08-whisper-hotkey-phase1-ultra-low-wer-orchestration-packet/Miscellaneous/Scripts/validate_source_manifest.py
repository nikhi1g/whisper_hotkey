#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
p=Path(__file__).resolve().parents[2]/'Sources'/'sources.json'; d=json.loads(p.read_text()); required={'id','category','title','authors','year','retrieved_or_checked','url','source_type','status','supports','caveat','phase'}; errors=[]
for i,s in enumerate(d.get('sources',[])):
 missing=required-set(s)
 if missing: errors.append(f'{i}: missing {sorted(missing)}')
 if s.get('phase')!=1: errors.append(f"{s.get('id')}: not phase 1")
 if not s.get('caveat'): errors.append(f"{s.get('id')}: missing caveat")
if errors: print('\n'.join(errors)); raise SystemExit(1)
print(f"validated {len(d['sources'])} source records")
