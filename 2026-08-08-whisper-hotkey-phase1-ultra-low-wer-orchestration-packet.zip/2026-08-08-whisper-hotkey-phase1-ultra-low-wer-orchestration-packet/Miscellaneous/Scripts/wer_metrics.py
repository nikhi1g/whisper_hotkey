#!/usr/bin/env python3
"""Deterministic WER/CER and basic display-text metrics. No third-party packages."""
from __future__ import annotations
import argparse, json, re, unicodedata
from dataclasses import dataclass

WORD_RE = re.compile(r"[\w]+(?:['’][\w]+)?", re.UNICODE)
PUNCT = set(".,?!:;")

def normalize_text(text: str) -> list[str]:
    text = unicodedata.normalize("NFKC", text).lower().replace("’", "'")
    return WORD_RE.findall(text)

def chars(text: str) -> list[str]:
    return list("".join(normalize_text(text)))

def edit_counts(ref: list[str], hyp: list[str]) -> tuple[int,int,int]:
    # Each cell is (distance, substitutions, deletions, insertions).
    prev=[(j,0,0,j) for j in range(len(hyp)+1)]
    for i,r in enumerate(ref,1):
        cur=[(i,0,i,0)]
        for j,h in enumerate(hyp,1):
            if r==h:
                cur.append(prev[j-1])
                continue
            sub=prev[j-1]; dele=prev[j]; ins=cur[j-1]
            options=[(sub[0]+1,sub[1]+1,sub[2],sub[3]),(dele[0]+1,dele[1],dele[2]+1,dele[3]),(ins[0]+1,ins[1],ins[2],ins[3]+1)]
            cur.append(min(options, key=lambda x:(x[0],x[1],x[2],x[3])))
        prev=cur
    _,s,d,i=prev[-1]
    return s,d,i

def rate(reference: str, hypothesis: str, character: bool=False) -> dict:
    r=chars(reference) if character else normalize_text(reference)
    h=chars(hypothesis) if character else normalize_text(hypothesis)
    s,d,i=edit_counts(r,h)
    n=len(r)
    return {'reference_units':n,'substitutions':s,'deletions':d,'insertions':i,'errors':s+d+i,'rate':(s+d+i)/n if n else (0.0 if not h else float('inf'))}

def punctuation_f1(reference: str, hypothesis: str) -> dict:
    def labels(t: str):
        words=[]; labels=[]
        for token in re.findall(r"[\w]+(?:['’][\w]+)?|[.,?!:;]", unicodedata.normalize('NFKC', t), re.UNICODE):
            if token in PUNCT:
                if labels: labels[-1]=token
            else:
                words.append(token.lower()); labels.append('NONE')
        return words,labels
    rw,rl=labels(reference); hw,hl=labels(hypothesis)
    if rw!=hw: return {'comparable':False,'macro_f1':None}
    classes=sorted(PUNCT|{'NONE'}); f1s=[]
    for c in classes:
        tp=sum(a==c and b==c for a,b in zip(rl,hl)); fp=sum(a!=c and b==c for a,b in zip(rl,hl)); fn=sum(a==c and b!=c for a,b in zip(rl,hl))
        p=tp/(tp+fp) if tp+fp else 0.0; r=tp/(tp+fn) if tp+fn else 0.0
        f1s.append(2*p*r/(p+r) if p+r else 0.0)
    return {'comparable':True,'macro_f1':sum(f1s)/len(f1s)}

def main():
    p=argparse.ArgumentParser(); p.add_argument('reference'); p.add_argument('hypothesis'); p.add_argument('--json', action='store_true'); a=p.parse_args()
    out={'wer':rate(a.reference,a.hypothesis),'cer':rate(a.reference,a.hypothesis,True),'punctuation':punctuation_f1(a.reference,a.hypothesis)}
    print(json.dumps(out,indent=2) if a.json else f"WER={out['wer']['rate']:.6f} CER={out['cer']['rate']:.6f} PUNC_F1={out['punctuation']['macro_f1']}")
if __name__=='__main__': main()
