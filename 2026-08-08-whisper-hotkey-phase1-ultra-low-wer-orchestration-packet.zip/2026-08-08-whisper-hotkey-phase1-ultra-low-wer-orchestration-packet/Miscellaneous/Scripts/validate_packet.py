#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
errors=[]
required=[ROOT/'README.md',ROOT/'MD'/'00_ORCHESTRATOR_START_HERE.md',ROOT/'Sources'/'00_SOURCE_INDEX.md',ROOT/'Sources'/'sources.json',ROOT/'Miscellaneous'/'Schemas'/'recognition-result-v1.schema.json']
for p in required:
    if not p.exists(): errors.append(f'missing {p.relative_to(ROOT)}')
workers=sorted((ROOT/'MD'/'Workers').glob('W*.md'))
if len(workers)<15: errors.append(f'expected >=15 worker packets, found {len(workers)}')
for p in ROOT.rglob('*.json'):
    try: json.loads(p.read_text())
    except Exception as e: errors.append(f'invalid JSON {p.relative_to(ROOT)}: {e}')
source_data=json.loads((ROOT/'Sources'/'sources.json').read_text())
ids=[s['id'] for s in source_data['sources']]
if len(ids)!=len(set(ids)): errors.append('duplicate source IDs')
for s in source_data['sources']:
    if not s['url'].startswith('https://'): errors.append(f"non-https source {s['id']}")
# Local markdown link existence; skip URLs and anchors.
link_re=re.compile(r'\[[^\]]*\]\(([^)]+)\)')
for p in ROOT.rglob('*.md'):
    text=p.read_text(errors='replace')
    if '\x00' in text: errors.append(f'NUL in {p.relative_to(ROOT)}')
    for target in link_re.findall(text):
        if target.startswith(('http://','https://','#','mailto:')): continue
        target=target.split('#',1)[0]
        if not target: continue
        candidate=(p.parent/target).resolve()
        try: candidate.relative_to(ROOT.resolve())
        except ValueError: errors.append(f'link escapes root: {p.relative_to(ROOT)} -> {target}'); continue
        if not candidate.exists(): errors.append(f'broken local link: {p.relative_to(ROOT)} -> {target}')
if errors:
    print('\n'.join(f'ERROR: {e}' for e in errors)); raise SystemExit(1)
print(f'packet valid: {len(list(ROOT.rglob("*")))} entries, {len(workers)} worker packets, {len(ids)} sources')
