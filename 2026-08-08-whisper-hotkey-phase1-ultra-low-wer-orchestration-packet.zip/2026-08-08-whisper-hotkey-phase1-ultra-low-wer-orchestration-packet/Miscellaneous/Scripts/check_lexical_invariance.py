#!/usr/bin/env python3
"""Fail if formatting changes lexical tokens or protected number strings."""
from __future__ import annotations
import argparse, json, re, sys, unicodedata
WORD=re.compile(r"[\w]+(?:['’][\w]+)?",re.UNICODE)
NUM=re.compile(r"(?:\d[\d,.:/%-]*\d|\d)")
def tokens(s): return [x.lower().replace('’',"'") for x in WORD.findall(unicodedata.normalize('NFKC',s))]
def nums(s): return NUM.findall(unicodedata.normalize('NFKC',s))
def main():
 p=argparse.ArgumentParser(); p.add_argument('before'); p.add_argument('after'); a=p.parse_args(); out={'tokens_equal':tokens(a.before)==tokens(a.after),'numbers_equal':nums(a.before)==nums(a.after),'before_tokens':tokens(a.before),'after_tokens':tokens(a.after),'before_numbers':nums(a.before),'after_numbers':nums(a.after)}; print(json.dumps(out,indent=2)); raise SystemExit(0 if out['tokens_equal'] and out['numbers_equal'] else 1)
if __name__=='__main__': main()
