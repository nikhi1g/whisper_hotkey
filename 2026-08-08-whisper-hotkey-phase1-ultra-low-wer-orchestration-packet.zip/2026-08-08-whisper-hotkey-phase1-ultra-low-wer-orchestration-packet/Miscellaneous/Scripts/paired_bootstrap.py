#!/usr/bin/env python3
"""Paired bootstrap confidence interval for corpus-level WER difference.
Input JSONL fields: id, reference, baseline, candidate.
"""
from __future__ import annotations
import argparse, json, random, statistics, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from wer_metrics import normalize_text, edit_counts

def totals(rows,key,indices):
    err=n=0
    for idx in indices:
        r=normalize_text(rows[idx]['reference']); h=normalize_text(rows[idx][key]); s,d,i=edit_counts(r,h); err+=s+d+i; n+=len(r)
    return err/n if n else 0.0

def main():
    p=argparse.ArgumentParser(); p.add_argument('jsonl'); p.add_argument('--samples',type=int,default=10000); p.add_argument('--seed',type=int,default=7); a=p.parse_args()
    rows=[json.loads(x) for x in Path(a.jsonl).read_text().splitlines() if x.strip()]
    if len(rows)<2: raise SystemExit('need at least two rows')
    rng=random.Random(a.seed); n=len(rows); diffs=[]
    for _ in range(a.samples):
        ids=[rng.randrange(n) for _ in range(n)]
        diffs.append(totals(rows,'candidate',ids)-totals(rows,'baseline',ids))
    diffs.sort(); lo=diffs[int(.025*len(diffs))]; hi=diffs[min(len(diffs)-1,int(.975*len(diffs)))]
    all_ids=list(range(n)); out={'n':n,'baseline_wer':totals(rows,'baseline',all_ids),'candidate_wer':totals(rows,'candidate',all_ids),'delta_candidate_minus_baseline':totals(rows,'candidate',all_ids)-totals(rows,'baseline',all_ids),'ci95':[lo,hi],'bootstrap_samples':a.samples,'seed':a.seed}
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
