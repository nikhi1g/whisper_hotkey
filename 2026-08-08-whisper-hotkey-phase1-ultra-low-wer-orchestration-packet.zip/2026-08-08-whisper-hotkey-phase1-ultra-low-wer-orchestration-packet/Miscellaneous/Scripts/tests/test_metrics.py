#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys, tempfile
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
from wer_metrics import rate, punctuation_f1
assert rate('the cat sat','the cat sat')['rate']==0
assert abs(rate('the cat sat','the dog sat')['rate']-1/3)<1e-12
assert rate('a b','a b c')['insertions']==1
assert punctuation_f1('Hello, world.','hello world')['comparable']
subprocess.run([sys.executable,str(HERE/'check_lexical_invariance.py'),'Hello world','Hello, world!'],check=True,stdout=subprocess.DEVNULL)
bad=subprocess.run([sys.executable,str(HERE/'check_lexical_invariance.py'),'fifteen milligrams','fifty milligrams'],stdout=subprocess.DEVNULL)
assert bad.returncode!=0
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'x.jsonl'; p.write_text('\n'.join(json.dumps(x) for x in [
  {'id':'1','reference':'a b c','baseline':'a x c','candidate':'a b c'},
  {'id':'2','reference':'d e f','baseline':'d e','candidate':'d e f'},
  {'id':'3','reference':'g h i','baseline':'g h i','candidate':'g h i'}]))
 out=subprocess.check_output([sys.executable,str(HERE/'paired_bootstrap.py'),str(p),'--samples','200','--seed','1'])
 d=json.loads(out); assert d['candidate_wer']<=d['baseline_wer']
print('metric tests passed')
