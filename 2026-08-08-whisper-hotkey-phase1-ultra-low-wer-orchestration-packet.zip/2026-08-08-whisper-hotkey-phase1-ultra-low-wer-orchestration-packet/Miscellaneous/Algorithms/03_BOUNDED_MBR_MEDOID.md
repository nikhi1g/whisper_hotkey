# Bounded MBR / Medoid Candidate Selection

For a small candidate set `H`, select the hypothesis minimizing confidence-weighted expected edit loss:

```text
risk(h) = sum over r in H of posterior(r) * weighted_edit_distance(h, r)
```

Use the model posterior only after temperature calibration. Include the primary transcript as a candidate and preserve locked anchors in the distance function.

## Practical limits

- Candidate count: small and fixed, for example 3 to 8.
- Apply only to uncertain spans, never the whole session by default.
- Cache pairwise distances.
- Reject selection when the best risk margin is below a configured ambiguity floor.

This is a decision rule, not permission to synthesize a novel sentence.
