# Stable Prefix and Revisable Tail

Maintain:

- an immutable committed prefix;
- a bounded revisable tail with overlapping audio;
- a candidate sentence boundary score;
- a monotonically increasing session generation.

Commit a prefix only when it is unchanged across enough successive hypotheses, ends before the protected overlap window, and satisfies endpoint/semantic completeness. A user pause alone cannot commit a sentence. On cancellation or generation mismatch, discard all uncommitted work.

The state grows with committed text, but active re-decoding stays bounded to the overlap/tail window.
