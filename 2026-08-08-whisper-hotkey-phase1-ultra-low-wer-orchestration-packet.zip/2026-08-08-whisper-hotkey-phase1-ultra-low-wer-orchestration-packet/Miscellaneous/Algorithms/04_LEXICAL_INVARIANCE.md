# Lexical Invariance for Formatting

The punctuation layer emits labels attached to stable word IDs:

```text
word_id -> {leading_case, trailing_punctuation, paragraph_break}
```

Before and after formatting:

1. strip formatting-only Unicode characters;
2. normalize apostrophe and hyphen policy consistently;
3. compare ordered lexical tokens and protected numeric tokens;
4. require identical word IDs and token sequence;
5. fail closed to the unformatted lexical transcript on mismatch.

Punctuation is allowed to change only punctuation, capitalization and spacing. Any word insertion, deletion, substitution or reordering is a pipeline bug.
