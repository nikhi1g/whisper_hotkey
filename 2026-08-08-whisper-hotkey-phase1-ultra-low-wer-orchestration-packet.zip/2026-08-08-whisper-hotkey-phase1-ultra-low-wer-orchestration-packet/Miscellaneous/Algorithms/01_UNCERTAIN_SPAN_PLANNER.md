# Uncertain Span Planner

## Inputs

- ordered primary words with start/end times;
- calibrated probability that each word is wrong;
- boundary and no-speech evidence;
- maximum span duration, word count and total verifier-audio budget.

## Procedure

```text
flag word i when p_error(i) >= threshold OR evidence is structurally invalid
merge adjacent flags when their timing gap <= merge_gap
expand each merged run by left/right context words and milliseconds
snap to safe VAD/word boundaries
merge expansions that now overlap
split any span that exceeds max_span_duration at the lowest-risk internal boundary
rank spans by expected repair value:
    sum(p_error * error_cost) - verifier_cost - anchor_risk
accept spans until total verifier duration and count budgets are exhausted
```

## Required invariants

- Span timestamps are monotonic and inside the session audio.
- High-confidence anchors remain available on both sides when possible.
- A span never grows without a hard cap.
- Unselected uncertainty remains visible to metrics; it is not silently counted as repaired.

## Complexity

Linear scan and interval merge: `O(W log W)` if sorting is needed, otherwise `O(W)` for already ordered words. Memory is `O(W)` with strict caps.
