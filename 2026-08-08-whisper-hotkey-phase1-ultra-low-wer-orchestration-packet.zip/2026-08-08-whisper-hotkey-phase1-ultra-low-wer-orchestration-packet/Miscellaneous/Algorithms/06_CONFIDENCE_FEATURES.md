# Confidence Feature Set

Start with features available without training a new neural confidence model:

- token log probability and posterior;
- token/frame entropy;
- N-best score/rank disagreement;
- word duration and timestamp stability;
- no-speech/VAD overlap;
- primary-versus-complementary-engine agreement;
- repeated-token/hallucination indicators;
- language/prompt sensitivity;
- local SNR and clipping indicators;
- left/right lexical consistency features that do not rewrite text.

Calibrate to `P(word is wrong | features)` using held-out data. Compare temperature scaling, isotonic regression and a small regularized logistic/gradient-boosted model. Choose the simplest method that meets calibration and error-detection gates across clean, noisy and spontaneous subsets.
