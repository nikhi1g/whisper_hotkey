# Timestamp-Aware Alignment

Use bounded dynamic programming only inside an uncertain span.

## Cost

```text
substitution(a,b) = lexical_distance(a,b)
                  + time_overlap_penalty(a,b)
                  + confidence_penalty(a,b)
insertion(b)      = base_insert + timing_gap_penalty(b)
deletion(a)       = base_delete + locked_anchor_penalty(a)
```

A locked high-confidence word has effectively infinite deletion/substitution cost unless an explicit safety exception is recorded.

## Backtrace output

Return typed operations with source word IDs, candidate word IDs, timing overlap and score decomposition. Never return only a rewritten string.

## Complexity

`O(n*m)` time and `O(min(n,m))` score memory, plus a bounded backtrace representation. Both `n` and `m` are capped by the span planner.
