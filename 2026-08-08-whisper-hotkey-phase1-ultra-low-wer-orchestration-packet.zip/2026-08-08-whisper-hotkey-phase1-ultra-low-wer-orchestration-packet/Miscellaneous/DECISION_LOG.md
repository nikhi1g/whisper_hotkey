# Decision Log

## D1: Phase 2 is excluded

No user enrollment, target-speaker model, stored corpus or continual training belongs in this packet.

## D2: Three layers are a staged DAG

The primary decode must produce words/timings before confidence-localized verification can run. Punctuation and verifier work can overlap after that point. This avoids pretending that three independent threads can safely rewrite the same text.

## D3: Original audio remains canonical

The verifier re-decodes bounded source-audio spans. It does not correct text from text alone.

## D4: Formatting cannot change words

Punctuation/capitalization is represented as labels on stable word IDs and validated for lexical invariance.

## D5: Larger model choice is empirical

The initial verifier matrix is: current cross-engine pairing, full Whisper large-v3, Parakeet 1.1B through a viable local runtime, then Qwen3-ASR/MLX only if needed. No model is selected from leaderboard reputation alone.

## D6: Accuracy claims are scoped

The desired <=1% WER is a measured target on a frozen app corpus, not a promise for all audio.
