# luna_worker Return Contract

- **Worker packet:**
- **Branch/worktree:**
- **Commit SHA:**
- **Exact files changed:**
- **Contract/API decisions:**
- **Tests run and results:**
- **Benchmark command and raw artifact path:**
- **WER/display/latency/memory delta:**
- **High-confidence corruption observations:**
- **Race/cancellation/audio-cleanup checks:**
- **Assumptions:**
- **Unresolved risks:**
- **Dependencies for the next worker:**

Do not merge your own branch.
