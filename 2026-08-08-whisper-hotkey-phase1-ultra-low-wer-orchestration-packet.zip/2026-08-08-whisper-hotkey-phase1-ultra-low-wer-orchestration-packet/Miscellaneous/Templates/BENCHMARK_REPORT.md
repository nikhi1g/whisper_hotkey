# Benchmark Report

## Reproducibility

- Commit SHA:
- Dependency lock hash:
- Model filenames and SHA-256:
- Hardware:
- macOS version:
- Power mode and thermal state:
- Corpus manifest hash:
- Normalization version:

## Accuracy

Report corpus-weighted and macro-by-subset metrics, paired confidence intervals, and the raw JSON artifact. Include names, numbers, homophones, punctuation, boundary and false-period slices.

## Reliability and performance

Report p50/p95/p99 latency, deadline fallbacks, cancellations, stale-generation drops, peak RSS, temporary audio bytes, and at least one 30-minute repeated-session soak test.

## Conclusion

No release claim without a frozen-corpus paired comparison and explicit regression accounting.
