# Verifier Experiment Report

## Configuration

- Primary engine/model:
- Verifier engine/model:
- Quantization/runtime:
- Hardware/macOS:
- Warm/cold state:
- Span selection thresholds:
- Candidate count/beam settings:

## Results

| Metric | Primary only | Selective verifier | Delta |
|---|---:|---:|---:|
| Normalized WER | | | |
| Display WER | | | |
| Repair precision | | | |
| Repair recall | | | |
| High-confidence corruption rate | | | |
| p50 completion latency | | | |
| p95 completion latency | | | |
| Peak RSS | | | |
| Energy/thermal observation | | | |

## Decision

`reject`, `continue experiment`, or `eligible for integration`, with evidence.
