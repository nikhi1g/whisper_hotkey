# Phase 1 Pull Request Checklist

- [ ] No Phase 2 personalization, enrollment or retained user corpus.
- [ ] Recognition result remains provider-neutral and bounded.
- [ ] Original audio is session-owned until all selected passes finish or cancel.
- [ ] No model worker writes to the UI or clipboard directly.
- [ ] Word IDs/timestamps stay monotonic and generation-safe.
- [ ] High-confidence anchors cannot be changed without an audited exception.
- [ ] Formatting passes lexical invariance and number-preservation checks.
- [ ] Queues, candidates, spans and audio buffers have hard limits.
- [ ] Cancellation, rapid restart and stale-result tests pass.
- [ ] Paired benchmark and raw artifacts are attached.
- [ ] Accuracy claim is scoped to the evaluated corpus and normalization.
